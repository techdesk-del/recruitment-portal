import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Calendar, 
  ChevronDown, 
  ChevronLeft,
  ChevronRight,
  ArrowRight, 
  Download 
} from 'lucide-react';
import { useRecruitment } from '../../context/RecruitmentContext';
import { CandidateSource } from '../../types';
import { Pagination, PortalLogo } from '../common';

export const MainDashboard: React.FC = () => {
  const { 
    metrics, 
    candidates, 
    jobs, 
    setActiveView, 
    setFilters, 
    setSelectedCandidate, 
    downloadResume 
  } = useRecruitment();

  const [dashPage, setDashPage] = useState(1);
  const [dashPageSize, setDashPageSize] = useState(5);

  // --- Horizontal Edge Hover Auto-Scroll for Recent Candidates Table ---
  const tableScrollRef = useRef<HTMLDivElement>(null);
  const scrollAnimRef = useRef<number | null>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const updateScrollState = useCallback(() => {
    if (!tableScrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = tableScrollRef.current;
    setCanScrollLeft(scrollLeft > 4);
    setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 4);
  }, []);

  const stopAutoScroll = useCallback(() => {
    if (scrollAnimRef.current !== null) {
      cancelAnimationFrame(scrollAnimRef.current);
      scrollAnimRef.current = null;
    }
  }, []);

  const startAutoScroll = useCallback((direction: 'left' | 'right', speed: number = 8) => {
    stopAutoScroll();
    const scrollStep = () => {
      const el = tableScrollRef.current;
      if (!el) return;
      const { scrollLeft, scrollWidth, clientWidth } = el;

      if (direction === 'right') {
        if (scrollLeft + clientWidth < scrollWidth - 1) {
          el.scrollLeft += speed;
          scrollAnimRef.current = requestAnimationFrame(scrollStep);
        } else {
          stopAutoScroll();
        }
      } else {
        if (scrollLeft > 1) {
          el.scrollLeft -= speed;
          scrollAnimRef.current = requestAnimationFrame(scrollStep);
        } else {
          stopAutoScroll();
        }
      }
      updateScrollState();
    };
    scrollAnimRef.current = requestAnimationFrame(scrollStep);
  }, [stopAutoScroll, updateScrollState]);

  useEffect(() => {
    const el = tableScrollRef.current;
    if (!el) return;
    updateScrollState();
    el.addEventListener('scroll', updateScrollState, { passive: true });
    window.addEventListener('resize', updateScrollState);
    return () => {
      el.removeEventListener('scroll', updateScrollState);
      window.removeEventListener('resize', updateScrollState);
      stopAutoScroll();
    };
  }, [updateScrollState, stopAutoScroll]);

  // Adaptive edge hover detection on the table container
  const handleTableMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = tableScrollRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const width = rect.width;
    const edgeThreshold = 110; // 110px threshold from left & right border

    if (mouseX > width - edgeThreshold && container.scrollLeft + container.clientWidth < container.scrollWidth - 2) {
      const intensity = (mouseX - (width - edgeThreshold)) / edgeThreshold;
      const speed = Math.max(4, Math.round(intensity * 14));
      startAutoScroll('right', speed);
    } else if (mouseX < edgeThreshold && container.scrollLeft > 2) {
      const intensity = (edgeThreshold - mouseX) / edgeThreshold;
      const speed = Math.max(4, Math.round(intensity * 14));
      startAutoScroll('left', speed);
    } else {
      stopAutoScroll();
    }
  };

  const paginatedRecentCandidates = candidates.slice(
    (dashPage - 1) * dashPageSize,
    dashPage * dashPageSize
  );

  const handlePortalFilter = (source: CandidateSource, referrerId?: string) => {
    setFilters({
      searchQuery: '',
      source: source,
      referrerId: referrerId,
      status: 'all',
      jobId: 'all',
      experienceRange: 'all',
      recruiter: 'all',
      dateRange: 'all',
      minRating: 0
    });
    setActiveView(source);
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12 font-sans">
      
      {/* Top Welcome Title & Filter Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Dashboard</h1>
          <p className="text-xs text-slate-500 font-normal mt-0.5">Welcome back, Urban Gaon • Recruitment Operations</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-normal text-slate-700 shadow-2xs cursor-pointer hover:border-slate-300 transition">
            <Calendar size={14} className="text-slate-400" />
            <span>Active Hiring Cycle (Q3)</span>
            <ChevronDown size={14} className="text-slate-400" />
          </div>
        </div>
      </div>

      {/* SECTION 1: PERFORMANCE • RECRUITMENT PIPELINE */}
      <div className="space-y-3">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          PERFORMANCE • RECRUITMENT PIPELINE
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          
          {/* Card 1: Total Applicants */}
          <div 
            onClick={() => setActiveView('candidates')}
            className="p-4 sm:p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs hover:shadow-xs hover:border-emerald-400 transition cursor-pointer flex flex-col justify-between min-h-[130px] sm:min-h-[140px]"
          >
            <span className="text-xs font-normal text-slate-500">Total Applicants</span>
            <div className="mt-2">
              <span className="text-2xl sm:text-3xl font-bold text-[#00a86b] tracking-tight">
                {metrics.totalApplications}
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">{metrics.statusBreakdown.applied} new applications</p>
            </div>
          </div>

          {/* Card 2: Active Pipeline */}
          <div 
            onClick={() => setActiveView('pipeline')}
            className="p-4 sm:p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs hover:shadow-xs hover:border-blue-400 transition cursor-pointer flex flex-col justify-between min-h-[130px] sm:min-h-[140px]"
          >
            <span className="text-xs font-normal text-slate-500">In Active Pipeline</span>
            <div className="mt-2">
              <span className="text-2xl sm:text-3xl font-bold text-[#2563eb] tracking-tight">
                {metrics.activeCandidates}
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">across {jobs.length} open positions</p>
            </div>
          </div>

          {/* Card 3: Conversion */}
          <div className="p-4 sm:p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs flex flex-col justify-between min-h-[130px] sm:min-h-[140px]">
            <span className="text-xs font-normal text-slate-500">Interview Conversion</span>
            <div className="mt-2">
              <span className="text-2xl sm:text-3xl font-bold text-[#f59e0b] tracking-tight">
                {metrics.overallConversionRate}%
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">{metrics.statusBreakdown.joined} hired • {metrics.statusBreakdown.offered} offered</p>
            </div>
          </div>

          {/* Card 4: Avg Time to Hire */}
          <div className="p-4 sm:p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs flex flex-col justify-between min-h-[130px] sm:min-h-[140px]">
            <span className="text-xs font-normal text-slate-500">Avg Time to Hire</span>
            <div className="mt-2">
              <span className="text-2xl sm:text-3xl font-bold text-[#0284c7] tracking-tight">
                {metrics.avgTimeToHireDays} <span className="text-lg sm:text-xl font-medium text-slate-400">days</span>
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">fast turnaround per candidate</p>
            </div>
          </div>

        </div>
      </div>

      {/* SECTION 2: PORTAL SOURCES • APPLICATIONS */}
      <div className="space-y-3">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
          PORTAL SOURCES • APPLICATIONS RECEIVED
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          
          {/* Card 1: LinkedIn */}
          <div 
            onClick={() => handlePortalFilter('linkedin')}
            className="p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs hover:shadow-xs hover:border-blue-400 transition cursor-pointer min-h-[140px] flex flex-col justify-between"
          >
            <span className="text-xs font-normal text-slate-500">LinkedIn EasyApply</span>
            <div className="mt-2">
              <span className="text-3xl font-bold text-[#2563eb]">
                {metrics.sourceBreakdown.linkedin || 0}
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">synced candidate applications</p>
            </div>
          </div>

          {/* Card 2: Naukri */}
          <div 
            onClick={() => handlePortalFilter('naukri')}
            className="p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs hover:shadow-xs hover:border-emerald-400 transition cursor-pointer min-h-[140px] flex flex-col justify-between"
          >
            <span className="text-xs font-normal text-slate-500">Naukri FastForward</span>
            <div className="mt-2">
              <span className="text-3xl font-bold text-[#00a86b]">
                {metrics.sourceBreakdown.naukri || 0}
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">verified candidate profiles</p>
            </div>
          </div>

          {/* Card 3: Indeed & Portals */}
          <div 
            onClick={() => handlePortalFilter('indeed')}
            className="p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs hover:shadow-xs hover:border-amber-400 transition cursor-pointer min-h-[140px] flex flex-col justify-between"
          >
            <span className="text-xs font-normal text-slate-500">Indeed & Other Portals</span>
            <div className="mt-2">
              <span className="text-3xl font-bold text-[#f59e0b]">
                {(metrics.sourceBreakdown.indeed || 0) + (metrics.sourceBreakdown.apna || 0) + (metrics.sourceBreakdown.urbangaon || 0)}
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">active portal applicants</p>
            </div>
          </div>

          {/* Card 4: Employee Referral */}
          <div 
            onClick={() => handlePortalFilter('referral')}
            className="p-6 rounded-2xl bg-white border border-slate-100 shadow-2xs hover:shadow-xs hover:border-purple-400 transition cursor-pointer min-h-[140px] flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-normal text-slate-500">Employee Referral</span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                Direct
              </span>
            </div>
            <div className="mt-2">
              <span className="text-3xl font-bold text-[#8b5cf6]">
                {metrics.sourceBreakdown.referral || 0}
              </span>
              <p className="text-xs text-slate-400 font-normal mt-1">internal employee referrals</p>
            </div>
          </div>

        </div>

        {/* Assigned HR Recruitment Team Access Bar */}
        <div className="p-3 bg-blue-50/50 border border-blue-100 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-blue-950 font-medium">
            <span className="text-base">👥</span>
            <span>Assigned HR Team:</span>
            <span className="text-blue-600 font-normal hidden md:inline">Active recruiters managing interview pipeline</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {[
              { name: 'Dr Sharmila Yadav', count: candidates.filter(c => c.recruiterAssigned === 'Dr Sharmila Yadav').length },
              { name: 'Satyaveer Singh', count: candidates.filter(c => c.recruiterAssigned === 'Satyaveer Singh').length }
            ].map(hr => (
              <button
                key={hr.name}
                onClick={() => {
                  setFilters(prev => ({ ...prev, recruiter: hr.name }));
                  setActiveView('candidates');
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:border-blue-500 text-slate-800 font-medium transition shadow-2xs text-xs"
              >
                <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0"></span>
                <span>{hr.name}</span>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-blue-50 text-blue-700">
                  {hr.count} Candidates
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* SECTION 3: RECENT CANDIDATES */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            RECENT CANDIDATE APPLICATIONS
          </div>
          <button
            onClick={() => setActiveView('candidates')}
            className="text-xs font-medium text-blue-600 hover:text-blue-700 flex items-center gap-1"
          >
            <span>View All ({candidates.length})</span>
            <ArrowRight size={13} />
          </button>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-2xs relative group">
          
          {/* Left Hover Scroll Guide Badge */}
          {canScrollLeft && (
            <div
              onMouseEnter={() => startAutoScroll('left', 11)}
              onMouseLeave={stopAutoScroll}
              onClick={() => tableScrollRef.current?.scrollBy({ left: -260, behavior: 'smooth' })}
              title="Hover or click to scroll left"
              className="absolute left-0 top-0 bottom-14 w-12 z-20 flex items-center justify-start pl-2 bg-gradient-to-r from-white via-white/80 to-transparent cursor-pointer transition-opacity"
            >
              <div className="w-8 h-8 rounded-full bg-white shadow-md border border-slate-200 text-slate-700 flex items-center justify-center hover:bg-blue-600 hover:text-white transition">
                <ChevronLeft size={18} />
              </div>
            </div>
          )}

          {/* Right Hover Scroll Guide Badge */}
          {canScrollRight && (
            <div
              onMouseEnter={() => startAutoScroll('right', 11)}
              onMouseLeave={stopAutoScroll}
              onClick={() => tableScrollRef.current?.scrollBy({ left: 260, behavior: 'smooth' })}
              title="Hover or click to scroll right"
              className="absolute right-0 top-0 bottom-14 w-12 z-20 flex items-center justify-end pr-2 bg-gradient-to-l from-white via-white/80 to-transparent cursor-pointer transition-opacity"
            >
              <div className="w-8 h-8 rounded-full bg-white shadow-md border border-slate-200 text-slate-700 flex items-center justify-center hover:bg-blue-600 hover:text-white transition">
                <ChevronRight size={18} />
              </div>
            </div>
          )}

          <div 
            ref={tableScrollRef}
            onMouseMove={handleTableMouseMove}
            onMouseLeave={stopAutoScroll}
            className="overflow-x-auto scroll-smooth touch-pan-x"
          >
            <table className="w-full text-left border-collapse min-w-[1100px]">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-100 text-[11px] font-semibold text-slate-500 uppercase tracking-wider select-none">
                  <th 
                    onMouseEnter={() => startAutoScroll('left', 10)}
                    className="py-3 px-5 min-w-[260px]"
                  >
                    Candidate
                  </th>
                  <th className="py-3 px-4 min-w-[180px]">Applied Role</th>
                  <th className="py-3 px-4 min-w-[160px]">Portal</th>
                  <th className="py-3 px-4 min-w-[160px]">Assigned HR</th>
                  <th className="py-3 px-4 min-w-[130px]">Experience</th>
                  <th className="py-3 px-4 whitespace-nowrap min-w-[140px]">Hiring Stage</th>
                  <th 
                    onMouseEnter={() => startAutoScroll('right', 10)}
                    className="py-3 px-4 text-left whitespace-nowrap min-w-[160px]"
                  >
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {paginatedRecentCandidates.map((cand) => (
                  <tr key={cand.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center">
                          {cand.name.charAt(0)}
                        </div>
                        <div>
                          <p 
                            onClick={() => setSelectedCandidate(cand)}
                            className="font-semibold text-slate-900 hover:text-blue-600 cursor-pointer text-sm"
                          >
                            {cand.name}
                          </p>
                          <p className="text-[11px] text-slate-400 font-normal">{cand.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">{cand.jobAppliedFor}</td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-50 border border-slate-200 text-slate-800">
                        <PortalLogo source={cand.source} size={15} />
                        <span className="capitalize">{cand.source === 'referral' ? 'Direct Referral' : cand.source === 'newspaper' ? 'Newspaper AD' : cand.source}</span>
                      </span>
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 font-medium text-xs">
                        <div className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 font-bold text-[9px] flex items-center justify-center shrink-0">
                          {(cand.recruiterAssigned || 'HR').charAt(0)}
                        </div>
                        <span>{cand.recruiterAssigned || 'Dr Sharmila Yadav'}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 font-normal">{cand.experienceYears} Years</td>
                    <td className="py-3.5 px-4">
                      <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-semibold capitalize">
                        {cand.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-left whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setSelectedCandidate(cand)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-[11px] transition"
                        >
                          Profile
                        </button>
                        <button
                          onClick={() => downloadResume(cand.id)}
                          className="p-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 transition"
                        >
                          <Download size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Recent Candidates Pagination */}
          <Pagination
            currentPage={dashPage}
            totalItems={candidates.length}
            pageSize={dashPageSize}
            onPageChange={setDashPage}
            onPageSizeChange={setDashPageSize}
            pageSizeOptions={[5, 10, 15]}
            itemLabel="candidates"
          />
        </div>
      </div>

    </div>
  );
};
