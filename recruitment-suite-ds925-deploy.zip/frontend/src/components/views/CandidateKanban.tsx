import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Download,
  Eye,
  Star,
  ChevronRight,
  ChevronLeft,
  Filter,
  FileDown
} from 'lucide-react';
import { useRecruitment } from '../../context/RecruitmentContext';
import { Candidate, CandidateStatus, CandidateSource } from '../../types';
import { PortalLogo } from '../common/PortalLogo';

export const CandidateKanban: React.FC = () => {
  const {
    candidates,
    jobs,
    filters,
    setFilters,
    updateCandidateStatus,
    updateCandidateRating,
    setSelectedCandidate,
    setPreviewResumeCandidate,
    downloadResume,
    bulkDownloadResumes
  } = useRecruitment();

  // --- Horizontal Hover Auto-Scroll for Pipeline Columns ---
  const kanbanScrollRef = useRef<HTMLDivElement>(null);
  const scrollAnimRef = useRef<number | null>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const updateScrollState = useCallback(() => {
    if (!kanbanScrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = kanbanScrollRef.current;
    setCanScrollLeft(scrollLeft > 4);
    setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 4);
  }, []);

  const stopAutoScroll = useCallback(() => {
    if (scrollAnimRef.current !== null) {
      cancelAnimationFrame(scrollAnimRef.current);
      scrollAnimRef.current = null;
    }
  }, []);

  const startAutoScroll = useCallback((direction: 'left' | 'right', speed: number = 10) => {
    stopAutoScroll();
    const scrollStep = () => {
      const el = kanbanScrollRef.current;
      if (!el) return;
      const { scrollLeft, scrollWidth, clientWidth } = el;

      if (direction === 'right') {
        if (scrollLeft + clientWidth < scrollWidth - 1) {
          el.scrollLeft += speed;
          scrollAnimRef.current = requestAnimationFrame(scrollStep);
        } else {
          stopAutoScroll();
        }
      } else {
        if (scrollLeft > 1) {
          el.scrollLeft -= speed;
          scrollAnimRef.current = requestAnimationFrame(scrollStep);
        } else {
          stopAutoScroll();
        }
      }
      updateScrollState();
    };
    scrollAnimRef.current = requestAnimationFrame(scrollStep);
  }, [stopAutoScroll, updateScrollState]);

  useEffect(() => {
    const el = kanbanScrollRef.current;
    if (!el) return;
    updateScrollState();
    el.addEventListener('scroll', updateScrollState, { passive: true });
    window.addEventListener('resize', updateScrollState);
    return () => {
      el.removeEventListener('scroll', updateScrollState);
      window.removeEventListener('resize', updateScrollState);
      stopAutoScroll();
    };
  }, [updateScrollState, stopAutoScroll]);

  const handleKanbanMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = kanbanScrollRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const width = rect.width;
    const edgeThreshold = 120; // 120px edge trigger zone

    if (mouseX > width - edgeThreshold && container.scrollLeft + container.clientWidth < container.scrollWidth - 2) {
      const intensity = (mouseX - (width - edgeThreshold)) / edgeThreshold;
      const speed = Math.max(5, Math.round(intensity * 18));
      startAutoScroll('right', speed);
    } else if (mouseX < edgeThreshold && container.scrollLeft > 2) {
      const intensity = (edgeThreshold - mouseX) / edgeThreshold;
      const speed = Math.max(5, Math.round(intensity * 18));
      startAutoScroll('left', speed);
    } else {
      stopAutoScroll();
    }
  };

  const columns: { status: CandidateStatus; label: string; color: string; border: string; bg: string }[] = [
    { status: 'applied', label: 'Applied', color: 'text-slate-700', border: 'border-slate-300', bg: 'bg-slate-100/90' },
    { status: 'screening', label: 'Screening', color: 'text-blue-700', border: 'border-blue-200', bg: 'bg-blue-50/70' },
    { status: 'shortlisted', label: 'Shortlisted', color: 'text-indigo-700', border: 'border-indigo-200', bg: 'bg-indigo-50/70' },
    { status: 'interview_r1', label: 'Interview Round 1 (Satya)', color: 'text-purple-700', border: 'border-purple-200', bg: 'bg-purple-50/70' },
    { status: 'interview_r2', label: 'Interview Round 2 (Dr Sharmila & CEO)', color: 'text-fuchsia-700', border: 'border-fuchsia-200', bg: 'bg-fuchsia-50/70' },
    { status: 'offered', label: 'Offered', color: 'text-amber-800', border: 'border-amber-200', bg: 'bg-amber-50/70' },
    { status: 'offer_accepted', label: 'Offer Accepted', color: 'text-teal-800', border: 'border-teal-200', bg: 'bg-teal-50/70' },
    { status: 'joined', label: 'Joined / Hired', color: 'text-emerald-800', border: 'border-emerald-200', bg: 'bg-emerald-50/70' }
  ];

  const sourceBadges: Record<CandidateSource, { label: string; class: string }> = {
    naukri: { label: 'Naukri', class: 'bg-blue-50 text-blue-700 border-blue-200' },
    linkedin: { label: 'LinkedIn', class: 'bg-sky-50 text-sky-700 border-sky-200' },
    indeed: { label: 'Indeed', class: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
    apna: { label: 'Apna.co', class: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    urbangaon: { label: 'UrbanGaon', class: 'bg-blue-50 text-blue-700 border-blue-200' },
    internshala: { label: 'Internshala', class: 'bg-cyan-50 text-cyan-700 border-cyan-200' },
    referral: { label: 'Referral', class: 'bg-purple-50 text-purple-700 border-purple-200' },
    newspaper: { label: 'Newspaper AD', class: 'bg-amber-50 text-amber-700 border-amber-200' },
    other: { label: 'Other', class: 'bg-slate-50 text-slate-700 border-slate-200' }
  };

  // Filter candidates
  const filteredCandidates = candidates.filter((cand) => {
    if (filters.source !== 'all' && cand.source !== filters.source) return false;
    if (filters.jobId !== 'all' && cand.jobId !== filters.jobId) return false;
    if (filters.searchQuery) {
      const q = filters.searchQuery.toLowerCase();
      const match =
        (cand.name || '').toLowerCase().includes(q) ||
        (cand.email || '').toLowerCase().includes(q) ||
        (cand.jobAppliedFor || '').toLowerCase().includes(q) ||
        (cand.tags || []).some(t => t.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const getNextStatus = (current: CandidateStatus): CandidateStatus | null => {
    const order: CandidateStatus[] = ['applied', 'screening', 'shortlisted', 'interview_r1', 'interview_r2', 'offered', 'offer_accepted', 'joined'];
    const idx = order.indexOf(current);
    return idx >= 0 && idx < order.length - 1 ? order[idx + 1] : null;
  };

  const getPrevStatus = (current: CandidateStatus): CandidateStatus | null => {
    const order: CandidateStatus[] = ['applied', 'screening', 'shortlisted', 'interview_r1', 'interview_r2', 'offered', 'offer_accepted', 'joined'];
    const idx = order.indexOf(current);
    return idx > 0 ? order[idx - 1] : null;
  };

  return (
    <div className="h-full flex flex-col space-y-4 animate-fade-in min-h-0">

      {/* Top Filter Bar in Light Mode */}
      <div className="shrink-0 p-3 sm:p-3.5 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-700 font-bold">
            <Filter size={14} className="text-blue-600" />
            <span>Filters:</span>
          </div>

          {/* Source Dropdown */}
          <select
            value={filters.source}
            onChange={(e) => setFilters((prev) => ({ ...prev, source: e.target.value as any }))}
            className="flex-1 sm:flex-initial min-w-[140px] px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Sources (Naukri, LinkedIn, Indeed...)</option>
            <option value="naukri">Naukri.com</option>
            <option value="linkedin">LinkedIn</option>
            <option value="indeed">Indeed</option>
            <option value="urbangaon">UrbanGaon Careers</option>
            <option value="internshala">Internshala</option>
            <option value="referral">Internal Referrals</option>
          </select>

          {/* Job Role Dropdown */}
          <select
            value={filters.jobId}
            onChange={(e) => setFilters((prev) => ({ ...prev, jobId: e.target.value }))}
            className="flex-1 sm:flex-initial min-w-[140px] px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-700 focus:outline-none focus:border-blue-500 max-w-xs truncate"
          >
            <option value="all">All Active Job Roles</option>
            {jobs.map((j) => (
              <option key={j.id} value={j.id}>
                {j.title}
              </option>
            ))}
          </select>

          {/* Clear Filters */}
          {(filters.source !== 'all' || filters.jobId !== 'all' || filters.searchQuery) && (
            <button
              onClick={() => setFilters((prev) => ({ ...prev, source: 'all', jobId: 'all', searchQuery: '' }))}
              className="text-xs text-blue-600 hover:text-blue-700 underline font-medium"
            >
              Reset Filters
            </button>
          )}
        </div>

        <div className="flex items-center justify-between sm:justify-end gap-2.5">
          <span className="text-xs text-slate-500">
            Showing <strong className="text-slate-900">{filteredCandidates.length}</strong> candidates
          </span>
          <button
            onClick={() => bulkDownloadResumes(filteredCandidates.map(c => c.id))}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200 transition shrink-0"
          >
            <FileDown size={13} />
            <span className="hidden xs:inline">Download</span> Visible
          </button>
        </div>
      </div>

      {/* Mobile Stage Selector Switcher Pills (Visible on small screens) */}
      <div className="sm:hidden shrink-0 flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {columns.map((col) => {
          const count = filteredCandidates.filter((c) => c.status === col.status).length;
          return (
            <button
              key={col.status}
              onClick={() => {
                const el = document.getElementById(`kanban-col-${col.status}`);
                el?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
              }}
              className="px-2.5 py-1 rounded-xl text-[11px] font-bold shrink-0 bg-white border border-slate-200 text-slate-700 active:scale-95 transition shadow-2xs"
            >
              <span>{col.label}</span>
              <span className="ml-1.5 px-1.5 py-0.2 rounded-full bg-slate-100 text-[10px] text-slate-600 font-bold">{count}</span>
            </button>
          );
        })}
      </div>

      {/* Kanban Stage Columns Container (Horizontal Scrollable with Edge Hover) */}
      <div className="flex-1 min-h-0 relative group overflow-hidden flex flex-col">
        {/* Left Scroll Indicator Badge */}
        {canScrollLeft && (
          <div
            onMouseEnter={() => startAutoScroll('left', 14)}
            onMouseLeave={stopAutoScroll}
            onClick={() => kanbanScrollRef.current?.scrollBy({ left: -340, behavior: 'smooth' })}
            title="Hover or click to scroll left"
            className="absolute left-0 top-0 bottom-2 w-14 z-30 flex items-center justify-start pl-2 bg-gradient-to-r from-slate-900/10 via-white/80 to-transparent cursor-pointer transition-opacity"
          >
            <div className="w-9 h-9 rounded-full bg-white shadow-lg border border-slate-200 text-slate-800 flex items-center justify-center hover:bg-blue-600 hover:text-white transition">
              <ChevronLeft size={20} />
            </div>
          </div>
        )}

        {/* Right Scroll Indicator Badge */}
        {canScrollRight && (
          <div
            onMouseEnter={() => startAutoScroll('right', 14)}
            onMouseLeave={stopAutoScroll}
            onClick={() => kanbanScrollRef.current?.scrollBy({ left: 340, behavior: 'smooth' })}
            title="Hover or click to scroll right"
            className="absolute right-0 top-0 bottom-2 w-14 z-30 flex items-center justify-end pr-2 bg-gradient-to-l from-slate-900/10 via-white/80 to-transparent cursor-pointer transition-opacity"
          >
            <div className="w-9 h-9 rounded-full bg-white shadow-lg border border-slate-200 text-slate-800 flex items-center justify-center hover:bg-blue-600 hover:text-white transition">
              <ChevronRight size={20} />
            </div>
          </div>
        )}

        <div
          ref={kanbanScrollRef}
          onMouseMove={handleKanbanMouseMove}
          onMouseLeave={stopAutoScroll}
          className="flex-1 min-h-0 flex items-stretch gap-3 sm:gap-4 overflow-x-auto pb-2 scroll-smooth touch-pan-x"
        >
          {columns.map((col) => {
            const colCandidates = filteredCandidates.filter((c) => c.status === col.status);

            return (
              <div
                key={col.status}
                id={`kanban-col-${col.status}`}
                className={`w-[85vw] max-w-[320px] sm:w-80 shrink-0 flex flex-col rounded-2xl border ${col.border} ${col.bg} p-3 sm:p-3.5 h-full shadow-2xs`}
              >
                {/* Column Header */}
                <div className="shrink-0 flex items-center justify-between pb-3 border-b border-slate-200/80 mb-3">
                  <div className="flex items-center gap-2">
                    <h3 className={`text-xs font-extrabold uppercase tracking-wider ${col.color}`}>{col.label}</h3>
                    <span className="w-5 h-5 rounded-full bg-white border border-slate-200 flex items-center justify-center text-[11px] font-bold text-slate-700 shadow-2xs">
                      {colCandidates.length}
                    </span>
                  </div>
                </div>

                {/* Cards Container */}
                <div className="flex-1 min-h-0 overflow-y-auto space-y-3 pr-1">
                  {colCandidates.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center py-10 px-4 text-center border-2 border-dashed border-slate-300 rounded-xl bg-white/50 min-h-[140px]">
                      <p className="text-xs text-slate-400 font-medium">No candidates in {col.label}</p>
                    </div>
                  ) : (
                    colCandidates.map((cand) => {
                      const badge = sourceBadges[cand.source];
                      const nextSt = getNextStatus(cand.status);
                      const prevSt = getPrevStatus(cand.status);

                      return (
                        <div
                          key={cand.id}
                          className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-blue-400 transition-all shadow-xs group flex flex-col justify-between gap-3"
                        >
                          <div>
                            {/* Top row: Source badge + ATS Match */}
                            <div className="flex items-center justify-between gap-2 mb-2">
                              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border inline-flex items-center gap-1 ${badge.class}`}>
                                <PortalLogo source={cand.source} size={12} />
                                <span>{badge.label}</span>
                              </span>
                              <span className="text-[10px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                {cand.atsMatchScore}% ATS
                              </span>
                            </div>

                            {/* Candidate Name & Role */}
                            <h4
                              onClick={() => setSelectedCandidate(cand)}
                              className="text-xs font-bold text-slate-900 hover:text-blue-600 cursor-pointer transition line-clamp-1"
                            >
                              {cand.name}
                            </h4>
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {cand.jobAppliedFor || <span className="text-amber-700 font-semibold">✏️ Role Not Set</span>}
                            </p>

                            {/* Quick Info Tags */}
                            <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[10px] text-slate-600">
                              <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">{cand.experienceYears}y Exp</span>
                              <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">{cand.expectedSalary}</span>
                              <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">{cand.noticePeriod}</span>
                            </div>

                            {/* Recruiter & Star Rating */}
                            <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500">
                              <span className="truncate max-w-[130px]" title="Assigned HR">
                                👤 {cand.recruiterAssigned || 'Satyaveer Singh'}
                              </span>
                              <div className="flex items-center gap-0.5">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star
                                    key={star}
                                    size={11}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      updateCandidateRating(cand.id, star);
                                    }}
                                    className={`cursor-pointer ${star <= cand.rating
                                      ? 'text-amber-500 fill-amber-500'
                                      : 'text-slate-300 hover:text-amber-400'
                                      }`}
                                  />
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Card Bottom Row: Resume Download + Stage Navigation */}
                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1">
                            {/* Resume Actions */}
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => setPreviewResumeCandidate(cand)}
                                title="Preview Resume"
                                className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                              >
                                <Eye size={12} />
                              </button>
                              <button
                                onClick={() => downloadResume(cand.id)}
                                title="Download PDF"
                                className="px-2 py-1 rounded bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] flex items-center gap-1 transition shadow-xs"
                              >
                                <Download size={11} />
                                <span>PDF</span>
                              </button>
                            </div>

                            {/* Stage Navigation Arrows */}
                            <div className="flex items-center gap-1">
                              {prevSt && (
                                <button
                                  onClick={() => updateCandidateStatus(cand.id, prevSt)}
                                  title={`Move back to ${prevSt}`}
                                  className="p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                                >
                                  <ChevronLeft size={13} />
                                </button>
                              )}
                              {nextSt && (
                                <button
                                  onClick={() => updateCandidateStatus(cand.id, nextSt)}
                                  title={`Advance to ${nextSt}`}
                                  className="p-1 rounded bg-blue-50 text-blue-700 hover:bg-blue-100 transition flex items-center gap-0.5 px-1.5 text-[10px] font-bold border border-blue-200"
                                >
                                  <span>Advance</span>
                                  <ChevronRight size={13} />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
