import { Candidate, JobPosting, InterviewSchedule, CallRecord } from '../types';

export const INITIAL_JOBS: JobPosting[] = [
  {
    "id": "job-am-sales",
    "title": "Assistant Manager – Sales",
    "department": "Sales",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "4–7 Years",
    "salaryRange": "",
    "openPositions": 2,
    "postedDate": "2026-09-10T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "apna",
      "linkedin",
      "referral"
    ],
    "applicantsCount": 16,
    "hiredCount": 0,
    "reportsTo": "Leadership / Management",
    "industry": "Real Estate Development",
    "mandatoryQualification": "Graduate — mandatory",
    "preferredQualification": "MBA — preferred, not mandatory",
    "rolePurpose": "Responsible for driving sales closures across UrbanGaon developments by managing lead follow-up, site visits, channel partner coordination, and customer counselling, while maintaining CRM discipline and ensuring accurate booking documentation and a smooth handoff to collections and customer service.",
    "responsibilities": [
      "Follow up on leads promptly and convert inquiries into site visits.",
      "Conduct site visits and property walkthroughs for prospective customers.",
      "Counsel customers on project offerings, pricing, and payment plans.",
      "Coordinate with channel partners (CPs) to generate and manage leads.",
      "Negotiate terms and close sales in line with approved pricing and policies.",
      "Maintain CRM discipline — timely and accurate updates on leads, visits, and status.",
      "Prepare and process booking documentation accurately and on time.",
      "Ensure a smooth handoff of closed bookings to collections and customer service teams.",
      "Build and maintain relationships with channel partners for repeat business.",
      "Achieve monthly and quarterly sales targets as assigned."
    ],
    "competencies": [
      "Strong negotiation and closing skills.",
      "Excellent customer handling and relationship-building ability.",
      "Established channel partner network and coordination skills.",
      "Disciplined CRM usage and process orientation.",
      "Target-driven with a strong sense of ownership.",
      "Good communication and presentation skills.",
      "Resilient, proactive, and self-motivated in a target-based environment."
    ]
  },
  {
    "id": "job-am-marketing",
    "title": "Assistant Manager – Marketing & Branding",
    "department": "Marketing & Branding",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "4–7 Years",
    "salaryRange": "",
    "openPositions": 2,
    "postedDate": "2026-09-11T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "linkedin",
      "naukri",
      "apna",
      "referral"
    ],
    "applicantsCount": 0,
    "hiredCount": 0,
    "reportsTo": "Leadership / Management",
    "industry": "Real Estate Development",
    "mandatoryQualification": "Graduate — mandatory",
    "preferredQualification": "MBA in Marketing — preferred, not mandatory",
    "rolePurpose": "Responsible for owning and driving brand campaigns and marketing execution across UrbanGaon developments — including project launch support, digital and social media presence, creative collateral, events, agency coordination, customer communication, and campaign performance tracking — to build strong brand visibility and support sales and business objectives.",
    "responsibilities": [
      "Plan and execute brand campaigns across projects, aligned with business and sales objectives.",
      "Support project launches through marketing plans, collateral, and go-to-market coordination.",
      "Manage digital and social media presence, content calendars, and online brand consistency.",
      "Develop and oversee creative collateral — brochures, signage, digital assets, and campaign creatives.",
      "Plan and execute marketing events, activations, and on-ground promotions.",
      "Coordinate with creative, digital, and media agencies to ensure timely, quality delivery.",
      "Manage customer communication and engagement across marketing touchpoints.",
      "Track and report campaign performance, ROI, and marketing effectiveness.",
      "Ensure brand consistency across all marketing materials and channels.",
      "Coordinate with sales and CRM teams to align marketing efforts with lead generation."
    ],
    "competencies": [
      "Strong understanding of branding, marketing, and campaign management fundamentals.",
      "Creative sensibility with an eye for design and brand consistency.",
      "Hands-on experience with digital/social media platforms and content planning.",
      "Ability to coordinate multiple agencies and vendors to deliver on time.",
      "Strong project management and multitasking ability across campaigns and launches.",
      "Data-oriented — comfortable tracking and reporting campaign performance and ROI.",
      "Clear communicator, collaborative, and customer-focused."
    ]
  },
  {
    "id": "job-ea-director",
    "title": "EA to Director",
    "department": "Administration / Director's Office",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "8–10 Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-12T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "linkedin",
      "referral"
    ],
    "applicantsCount": 9,
    "hiredCount": 0,
    "reportsTo": "Director",
    "industry": "Real Estate Development",
    "mandatoryQualification": "Graduate in any discipline — mandatory",
    "preferredQualification": "MBA preferred",
    "rolePurpose": "Responsible for managing the Director's calendar, confidential correspondence, meeting minutes, travel, and communication — including MIS reporting, cross-functional action tracking, document preparation, and priority coordination — to ensure seamless and efficient support to the Director.",
    "responsibilities": [
      "Manage the Director's calendar, appointments, and scheduling priorities.",
      "Handle confidential correspondence and follow-ups with discretion.",
      "Prepare accurate meeting minutes and track action items to closure.",
      "Coordinate domestic and international travel arrangements and itineraries.",
      "Manage internal and external communication on behalf of the Director.",
      "Prepare and maintain MIS reports and dashboards for leadership review.",
      "Track cross-functional actions and follow-ups across departments.",
      "Prepare documents, presentations, and briefing notes for meetings.",
      "Coordinate and prioritize competing demands on the Director's time.",
      "Liaise with internal stakeholders and external contacts for smooth coordination.",
      "Maintain confidentiality and professionalism in handling sensitive matters."
    ],
    "competencies": [
      "Strong communication and interpersonal skills, both written and verbal.",
      "High level of discretion, integrity, and confidentiality.",
      "Proficiency in MS Office (Word, Excel, PowerPoint, Outlook).",
      "Excellent minute-taking and documentation skills.",
      "Strong follow-up discipline and ownership of action items.",
      "Ability to multitask and manage competing priorities under pressure.",
      "Professional demeanor with strong organizational and time-management skills."
    ]
  },
  {
    "id": "job-head-ai-it",
    "title": "Head of AI Adoption, IT & Research",
    "department": "AI, IT & Research",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "10–15+ Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-14T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "linkedin",
      "naukri",
      "referral"
    ],
    "applicantsCount": 2,
    "hiredCount": 0,
    "reportsTo": "Leadership / Management",
    "industry": "Real Estate Development",
    "mandatoryQualification": "B.Tech / MCA — mandatory",
    "preferredQualification": "MBA-Tech hybrid or additional certification in AI/digital transformation — preferred, not mandatory",
    "rolePurpose": "Responsible for leading practical AI adoption, IT systems, automation, and research intelligence across UrbanGaon, driving digital productivity tools, vendor selection, cybersecurity hygiene, and cross-functional training to enable a technology-forward, data-driven organisation.",
    "responsibilities": [
      "Identify and implement practical AI use cases across business functions.",
      "Own and manage IT systems, infrastructure, and digital tools.",
      "Drive automation of manual processes to improve efficiency.",
      "Build data and reporting frameworks to support decision-making.",
      "Lead research intelligence — market, competitor, and technology trends.",
      "Evaluate and roll out digital productivity tools across teams.",
      "Manage vendor selection, evaluation, and contracts for IT/AI solutions.",
      "Ensure cybersecurity hygiene and data protection practices are followed.",
      "Conduct cross-functional training on AI tools and digital adoption.",
      "Partner with leadership and department heads to align technology with business goals.",
      "Monitor and report on AI/IT adoption impact and ROI."
    ],
    "competencies": [
      "Strong understanding of AI, IT systems, and digital transformation practices.",
      "Ability to identify practical, high-impact AI use cases for the business.",
      "Strong stakeholder management across leadership and cross-functional teams.",
      "Vendor management and negotiation skills.",
      "Data-driven mindset with strong analytical ability.",
      "Awareness of cybersecurity best practices and data protection.",
      "Strong communication and training/facilitation skills."
    ]
  },
  {
    "id": "job-head-architecture",
    "title": "Head of Architecture",
    "department": "Architecture & Design",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "12–18+ Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-15T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "linkedin",
      "referral"
    ],
    "applicantsCount": 3,
    "hiredCount": 0,
    "reportsTo": "Leadership / Management",
    "industry": "Real Estate Development",
    "mandatoryQualification": "Bachelor of Architecture (B.Arch.) with valid Council of Architecture registration",
    "preferredQualification": "Master of Architecture (M.Arch.), BIM / Sustainable Design / Project Management Certification",
    "rolePurpose": "Responsible for leading the complete architectural function across all UrbanGaon developments by driving concept design, design development, consultant coordination, statutory approvals, value engineering, execution support and design governance while ensuring quality, compliance, cost optimization and timely project delivery.",
    "responsibilities": [
      "Lead concept planning through construction support.",
      "Ensure architectural excellence across all projects.",
      "Coordinate Structural, MEP, Landscape and Interior consultants.",
      "Review and approve drawings before release.",
      "Drive statutory approvals.",
      "Implement value engineering.",
      "Support execution teams through site reviews.",
      "Standardize design documentation and QA.",
      "Present designs to leadership.",
      "Develop and mentor the architecture team.",
      "Monitor industry trends and sustainable practices."
    ],
    "competencies": [
      "Expertise in architectural planning and execution.",
      "Knowledge of NBC, local bye-laws and approvals.",
      "Leadership and consultant management.",
      "Value engineering and constructability review.",
      "AutoCAD, Revit, BIM and presentation skills.",
      "Excellent communication and stakeholder management.",
      "Ownership, integrity and continuous improvement mindset."
    ]
  },
  {
    "id": "job-research-analyst",
    "title": "In-house Research Analyst",
    "department": "AI, IT & Research",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "3–6 Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-16T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "linkedin",
      "naukri",
      "internshala",
      "referral"
    ],
    "applicantsCount": 0,
    "hiredCount": 0,
    "reportsTo": "Head of AI Adoption, IT & Research",
    "industry": "Real Estate Development",
    "mandatoryQualification": "Graduate in Computer Science / IT / AI / Data Science / Engineering (or related technical discipline) — mandatory",
    "preferredQualification": "MCA / M.Tech in AI, Data Science, IT, or Business Analytics — preferred, not mandatory",
    "rolePurpose": "Responsible for driving in-house research intelligence covering market, competitor, and technology trends to support strategic decision-making across UrbanGaon, delivering timely and actionable insights to leadership and cross-functional teams.",
    "responsibilities": [
      "Conduct market research on real estate trends, pricing, and demand patterns.",
      "Track competitor projects, launches, pricing, and positioning.",
      "Track and evaluate emerging AI, IT, and technology tools/trends relevant to the business, and monitor industry and regulatory developments.",
      "Build and maintain research databases and knowledge repositories, leveraging AI/IT tools to automate data collection and analysis.",
      "Prepare research reports, dashboards, and presentations for leadership.",
      "Support due diligence for new projects, land acquisitions, and market-entry decisions.",
      "Collaborate with sales, marketing, and strategy teams to translate research into actionable insights.",
      "Conduct primary research (surveys, site visits, customer interviews) as needed.",
      "Benchmark organisational performance against industry standards and best practices.",
      "Ensure research outputs are timely, accurate, and well-sourced."
    ],
    "competencies": [
      "Strong research and analytical skills with attention to detail.",
      "Ability to synthesise large volumes of information into clear, actionable insights.",
      "Proficiency in MS Excel, PowerPoint, and research/data tools; working knowledge of AI tools, data analytics platforms, and SQL/Python is a strong plus.",
      "Good understanding of real estate market dynamics and interest in AI/IT adoption trends (preferred).",
      "Strong written and verbal communication skills.",
      "Ability to manage multiple research requests within tight timelines.",
      "Curiosity and a proactive approach to tracking industry and market trends."
    ]
  },
  {
    "id": "job-project-manager",
    "title": "Project Manager",
    "department": "Civil",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "10–15 Years",
    "salaryRange": "",
    "openPositions": 2,
    "postedDate": "2026-09-18T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "referral",
      "linkedin"
    ],
    "applicantsCount": 2,
    "hiredCount": 0,
    "reportsTo": "Leadership / Management",
    "industry": "Real Estate Development",
    "mandatoryQualification": "B.E. / B.Tech / Diploma in Civil Engineering, with a strong execution background — mandatory",
    "preferredQualification": "Additional certification in project management (e.g., PMP) — an added advantage",
    "rolePurpose": "Responsible for owning end-to-end project execution across UrbanGaon developments — including scheduling, contractor management, site coordination, quality and safety compliance, cost tracking, billing coordination, and project reporting — to ensure timely and quality delivery of project milestones.",
    "responsibilities": [
      "Own overall project execution and ensure delivery as per the approved schedule.",
      "Prepare, monitor, and update project schedules and milestones.",
      "Coordinate and manage contractors, sub-contractors, and site teams.",
      "Ensure quality standards are maintained across all stages of construction.",
      "Implement and monitor site safety protocols and compliance.",
      "Track project costs and monitor budget adherence.",
      "Coordinate billing and certification of contractor and vendor payments.",
      "Prepare and present regular project progress reports to leadership.",
      "Resolve on-site execution issues and coordinate with design and consultant teams.",
      "Ensure timely procurement and availability of materials for site progress.",
      "Drive milestone delivery and proactively flag delays or risks."
    ],
    "competencies": [
      "Strong technical knowledge of building construction and execution practices.",
      "Proven ability to plan, schedule, and monitor large projects.",
      "Strong contractor and vendor management skills.",
      "Sound understanding of quality and safety standards on site.",
      "Cost-conscious with strong budget tracking discipline.",
      "Clear, structured reporting and communication skills.",
      "Ownership-driven, proactive, and solution-oriented under pressure."
    ]
  },
  {
    "id": "job-purchase-officer-china",
    "title": "Purchase Officer – International Procurement (China Exposure)",
    "department": "Procurement / Supply Chain",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "5–10 Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-19T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "linkedin",
      "referral"
    ],
    "applicantsCount": 0,
    "hiredCount": 0,
    "reportsTo": "Procurement Manager",
    "industry": "Consumer Electronics / Real Estate",
    "mandatoryQualification": "Graduate — mandatory",
    "preferredQualification": "Supply Chain / Commerce / Engineering background — an added advantage",
    "rolePurpose": "Responsible for sourcing materials from China and international suppliers — including preparing RFQs, comparing landed costs, negotiating terms, coordinating samples, verifying vendors, managing import documentation and logistics, and monitoring quality and supplier performance — to ensure timely, cost-effective, and quality procurement.",
    "responsibilities": [
      "Source materials and equipment from Chinese and other international suppliers.",
      "Prepare and issue RFQs (Request for Quotations) to prospective vendors.",
      "Compare landed costs across suppliers, including freight, duties, and taxes.",
      "Negotiate pricing, payment terms, and delivery schedules with suppliers.",
      "Coordinate sample requests, approvals, and quality benchmarking.",
      "Conduct vendor verification and due diligence before onboarding.",
      "Prepare and manage import documents such as invoices, packing lists, and certificates of origin.",
      "Coordinate logistics, shipping, and customs clearance with freight forwarders.",
      "Monitor quality control (QC) at source and upon receipt of goods.",
      "Track and evaluate supplier performance on cost, quality, and delivery.",
      "Maintain accurate purchase records and support cost-saving initiatives."
    ],
    "competencies": [
      "Strong negotiation skills with international vendors.",
      "Proficiency in Excel for cost comparison and analysis.",
      "Sound knowledge of import documentation and customs procedures.",
      "Strong written and verbal English communication skills.",
      "Ability to evaluate quality and conduct vendor due diligence.",
      "Detail-oriented with strong follow-up and coordination skills.",
      "Ability to manage multiple suppliers and shipments simultaneously."
    ]
  },
  {
    "id": "job-supervisor-civil",
    "title": "Supervisor (Civil)",
    "department": "Civil",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "3–8 Years",
    "salaryRange": "",
    "openPositions": 3,
    "postedDate": "2026-09-20T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "newspaper",
      "naukri",
      "apna"
    ],
    "applicantsCount": 2,
    "hiredCount": 0,
    "reportsTo": "Project Manager",
    "industry": "Real Estate Development",
    "mandatoryQualification": "10+2 with relevant site experience — mandatory",
    "preferredQualification": "Diploma in Civil Engineering — preferred",
    "rolePurpose": "Responsible for supervising daily site activity — including labor and vendor coordination, drawing execution, material tracking, quality checks, safety discipline, and daily progress reporting — and escalating site issues promptly to ensure smooth on-site execution.",
    "responsibilities": [
      "Supervise daily site activities and ensure work progresses as per plan.",
      "Coordinate labor and vendor teams for efficient site execution.",
      "Execute work as per approved drawings and specifications.",
      "Track material consumption, wastage, and stock at site.",
      "Conduct quality checks at each stage of construction.",
      "Enforce safety discipline and ensure use of PPE on site.",
      "Prepare and submit daily progress reports to the Project Manager.",
      "Escalate site issues, delays, or discrepancies promptly.",
      "Coordinate with contractors and sub-contractors on daily work allocation.",
      "Ensure housekeeping and site cleanliness standards are maintained.",
      "Support inspection and audit activities as required."
    ],
    "competencies": [
      "Practical, hands-on knowledge of civil construction workflow.",
      "Strong labor and manpower handling skills.",
      "Ability to read and execute technical drawings accurately.",
      "Sound understanding of site safety practices and discipline.",
      "Attention to detail in material tracking and quality checks.",
      "Ability to identify and escalate site issues promptly.",
      "Strong ownership and hands-on execution mindset."
    ]
  },
  {
    "id": "job-accounts-manager-head",
    "title": "Accounts Manager (Head)",
    "department": "Accounts & Finance",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "4–8 Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-21T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "linkedin",
      "referral"
    ],
    "applicantsCount": 0,
    "hiredCount": 0,
    "reportsTo": "Leadership / Management",
    "industry": "Construction / Real Estate Development",
    "mandatoryQualification": "Commerce Post Graduate (M.Com) — mandatory",
    "preferredQualification": "CA Inter — preferred, not mandatory",
    "rolePurpose": "Responsible for leading the accounts function across UrbanGaon construction projects by ensuring accurate bookkeeping, timely statutory compliance, project-wise cost and vendor accounting, and reliable financial reporting, while maintaining strong internal controls and supporting management with MIS and audit readiness.",
    "responsibilities": [
      "Lead and oversee day-to-day accounting operations, including books of accounts, ledgers, and bank and cash management.",
      "Maintain accurate and up-to-date accounts in Tally, with regular review and reconciliation.",
      "Manage project-wise accounting, including cost tracking, budget-vs-actual analysis, and work-in-progress (WIP) accounting.",
      "Process and verify contractor and vendor bills, running bills, retention, advances, and payments.",
      "Ensure timely GST, TDS, TCS, PF/ESI and other statutory filings, including RERA-related accounting requirements.",
      "Prepare monthly, quarterly, and annual financial statements and MIS reports for management.",
      "Coordinate with auditors, tax consultants, and banks for statutory audits, assessments, and financial queries.",
      "Monitor cash flow and fund requirements across projects, and maintain strong internal controls and accounting policies.",
      "Supervise, guide, and train the accounts team to ensure accuracy and timely closures."
    ],
    "competencies": [
      "Strong working knowledge of Tally (ERP / Prime) and accounting software.",
      "Good hands-on knowledge of accounting laws, GST, TDS, Income Tax, and Companies Act provisions.",
      "Experience in construction or real estate accounting, including project and contractor accounting.",
      "Strong analytical, reconciliation, and MIS-preparation skills.",
      "Leadership ability to guide a team and coordinate with auditors and consultants.",
      "Good communication skills and a strong sense of ownership and integrity."
    ]
  },
  {
    "id": "job-deputy-project-manager",
    "title": "Deputy Project Manager",
    "department": "Civil",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "4–9 Years",
    "salaryRange": "",
    "openPositions": 2,
    "postedDate": "2026-09-22T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "apna",
      "referral"
    ],
    "applicantsCount": 12,
    "hiredCount": 0,
    "reportsTo": "Project Manager / Head – Projects",
    "industry": "Real Estate Development",
    "mandatoryQualification": "B.E. / B.Tech / Diploma in Civil Engineering, with a solid site execution background — mandatory",
    "preferredQualification": "PMP or similar project management certification; MS Project / Primavera — an added advantage",
    "rolePurpose": "Responsible for supporting the Project Manager in project execution across UrbanGaon developments — including site management, scheduling, contractor coordination, quality and safety compliance, cost monitoring, billing support, and reporting — and leading the project in the Project Manager's absence.",
    "responsibilities": [
      "Support the Project Manager in overall project execution and drive day-to-day site progress as per the approved schedule.",
      "Assist in preparing, monitoring, and updating project schedules, look-ahead plans, and milestones.",
      "Coordinate with contractors, sub-contractors, and site teams; supervise daily work allocation.",
      "Conduct regular site inspections to ensure quality standards are maintained across all stages of construction.",
      "Implement and monitor site safety protocols, and ensure compliance through regular checks and toolbox talks.",
      "Track quantities, project costs, and budget adherence, and escalate variances to the Project Manager.",
      "Verify measurements and support billing and certification of contractor and vendor payments.",
      "Prepare daily, weekly, and monthly progress reports for the Project Manager and leadership.",
      "Resolve on-site issues and coordinate with design and consultant teams on drawings and approvals.",
      "Follow up on procurement and ensure timely availability of materials for site progress.",
      "Proactively flag delays or risks to the Project Manager, and lead the project in the Project Manager's absence."
    ],
    "competencies": [
      "Sound technical knowledge of building construction and execution practices.",
      "Ability to plan, schedule, and monitor project activities using scheduling tools.",
      "Good contractor and vendor coordination skills.",
      "Sound understanding of quality and safety standards on site.",
      "Cost-conscious with good budget tracking discipline.",
      "Clear, structured reporting and communication skills.",
      "Ownership-driven, proactive, and solution-oriented, ready to step into a leadership role."
    ]
  },
  {
    "id": "job-purchase-manager-construction",
    "title": "Purchase Manager – Construction Procurement",
    "department": "Procurement / Supply Chain & Contracts",
    "location": "Jaipur, Rajasthan",
    "type": "Full-time",
    "experienceRequired": "5–10 Years",
    "salaryRange": "",
    "openPositions": 1,
    "postedDate": "2026-09-23T09:00:00.000Z",
    "status": "active",
    "platforms": [
      "naukri",
      "referral",
      "linkedin"
    ],
    "applicantsCount": 1,
    "hiredCount": 0,
    "reportsTo": "Head of Procurement / Project Director",
    "industry": "Construction / Infrastructure & Real Estate Development",
    "mandatoryQualification": "Graduate — mandatory",
    "preferredQualification": "B.E. / B.Tech (Civil) or MBA in Supply Chain / Materials Management — an added advantage",
    "rolePurpose": "Responsible for planning and managing the procurement of construction materials, equipment, and subcontract packages across projects — including preparing RFQs and tender comparisons, negotiating rates and terms, developing and evaluating vendors and subcontractors, coordinating site deliveries, and ensuring material quality and compliance — to deliver timely, cost-effective, and quality procurement within project budgets and schedules.",
    "responsibilities": [
      "Plan and manage procurement of construction materials (cement, steel, aggregates, electrical, finishing) and equipment as per project schedules.",
      "Prepare and issue RFQs and tender documents; conduct technical and commercial bid comparisons.",
      "Negotiate rates, payment terms, and delivery schedules with suppliers and subcontractors; finalize rate contracts.",
      "Prepare and issue purchase orders and work orders in line with BOQ and approved budgets.",
      "Develop, empanel, and verify vendors and subcontractors through due diligence and site visits.",
      "Coordinate with project and site teams to track material requirements and ensure timely delivery to site.",
      "Ensure material quality as per specifications and approved samples; resolve rejections with vendors.",
      "Verify vendor invoices and GRNs, ensure GST compliance, and maintain purchase records and MIS reports."
    ],
    "competencies": [
      "Strong negotiation and commercial acumen with suppliers and subcontractors.",
      "Sound knowledge of construction materials, specifications, and market rates.",
      "Ability to read BOQs, drawings, and technical specifications.",
      "Proficiency in Excel and ERP / procurement software for cost comparison and MIS.",
      "Knowledge of contracts, GST, and statutory compliance in construction.",
      "Strong English and Hindi communication, with good follow-up and coordination skills."
    ]
  }
];

export const INITIAL_CANDIDATES: Candidate[] = [
  {
    "id": "cand-001",
    "name": "Naveen",
    "email": "naveen@example.com",
    "phone": "+91 98290 12323",
    "location": "Jaipur, Rajasthan",
    "source": "referral",
    "sourceId": "REFERRAL-1001",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-09-18T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-21T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "referral",
      "DPM",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 1 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-001",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-001.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-21T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-21",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-21T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-18T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r1",
      "nextFollowUpDate": "2026-09-21",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-1",
          "candidateId": "cand-001",
          "candidateName": "Naveen",
          "candidatePhone": "+91 98290 12323",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-18T09:30:00.000Z",
          "durationSeconds": 335,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-09-21",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "referral",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676491-1-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-21T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-1-apply",
        "action": "Application Ingested via Referrals",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-18T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-002",
    "name": "Sushmita Tailang",
    "email": "sushmita.tailang@example.com",
    "phone": "+91 98290 12346",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1002",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "appliedDate": "2026-09-19T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-21T12:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 62,
    "rating": 2,
    "experienceYears": 4,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "EA",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 2 for Executive Assistant (EA).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-002",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-002.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Assistant (EA) with over 4 years of progressive experience delivering excellence in Executive Office. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Executive Calendar Management",
        "Stakeholder Communication",
        "Travel Logistics",
        "Confidential Reporting",
        "Meeting Documentation",
        "ERP Operations",
        "Cross-functional Alignment"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Assistant (EA) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Executive Office, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Assistant (EA)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Assistant (EA)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Executive Office, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 2,
      "problemSolving": 2,
      "communication": 3,
      "cultureFit": 2,
      "overallRecommendation": "do_not_hire",
      "evaluationNotes": "Did not meet current technical or logistical criteria.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-09-21T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-09-21",
        "interviewStartTime": "11:00",
        "department": "Executive Office",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "do_not_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-09-21T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-19T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Executive Assistant (EA). Status: rejected",
      "nextFollowUpDate": "2026-09-21",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-2",
          "candidateId": "cand-002",
          "candidateName": "Sushmita Tailang",
          "candidatePhone": "+91 98290 12346",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-09-19T09:30:00.000Z",
          "durationSeconds": 350,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Assistant (EA).",
          "followUpDate": "2026-09-21",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "EA"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-2-r1",
        "action": "Round 1 Interview REJECTED",
        "details": "First round screening interview: Rejected",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-09-21T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-2-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Executive Assistant (EA)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-19T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-003",
    "name": "Ram Sahu",
    "email": "ram.sahu@example.com",
    "phone": "+91 98290 12369",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1003",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-09-17T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-26T12:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 62,
    "rating": 2,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "DPM",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 3 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-003",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-003.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 2,
      "problemSolving": 2,
      "communication": 3,
      "cultureFit": 2,
      "overallRecommendation": "do_not_hire",
      "evaluationNotes": "Did not meet current technical or logistical criteria.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-26T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-26",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "do_not_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-26T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-17T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: rejected",
      "nextFollowUpDate": "2026-09-26",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-3",
          "candidateId": "cand-003",
          "candidateName": "Ram Sahu",
          "candidatePhone": "+91 98290 12369",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-17T09:30:00.000Z",
          "durationSeconds": 365,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-09-26",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-3-r1",
        "action": "Round 1 Interview REJECTED",
        "details": "First round screening interview: Rejected",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-26T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-3-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-17T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-004",
    "name": "Gaurav Kumar Goyal",
    "email": "gaurav.kumar.goyal@example.com",
    "phone": "+91 98290 12392",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1004",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-09-17T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-26T12:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 62,
    "rating": 2,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "DPM",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 4 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-004",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-004.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 2,
      "problemSolving": 2,
      "communication": 3,
      "cultureFit": 2,
      "overallRecommendation": "do_not_hire",
      "evaluationNotes": "Did not meet current technical or logistical criteria.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-26T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-26",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "do_not_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-26T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-17T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: rejected",
      "nextFollowUpDate": "2026-09-26",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-4",
          "candidateId": "cand-004",
          "candidateName": "Gaurav Kumar Goyal",
          "candidatePhone": "+91 98290 12392",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-17T09:30:00.000Z",
          "durationSeconds": 380,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-09-26",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-4-r1",
        "action": "Round 1 Interview REJECTED",
        "details": "First round screening interview: Rejected",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-26T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-4-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-17T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-005",
    "name": "Daleep",
    "email": "daleep@example.com",
    "phone": "+91 98290 12415",
    "location": "Jaipur, Rajasthan",
    "source": "newspaper",
    "sourceId": "NEWSPAPER-1005",
    "jobAppliedFor": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "department": "Logistics & Administration",
    "appliedDate": "2026-09-16T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-28T12:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 62,
    "rating": 2,
    "experienceYears": 7,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Supervisor (Civil)",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹3,00,000 - ₹4,20,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "newspaper",
      "Driver",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 5 for Executive Fleet Driver.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-005",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-005.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Fleet Driver with over 7 years of progressive experience delivering excellence in Logistics & Administration. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "VIP Fleet Navigation",
        "Defensive Driving",
        "Vehicle Maintenance",
        "Route Optimization",
        "Road Safety Standards",
        "GPS Logistics",
        "Clean Driving Record"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Fleet Driver - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Logistics & Administration, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Fleet Driver",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Senior Secondary Education & Professional Commercial Driving Certification",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Fleet Driver",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Logistics & Administration, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 2,
      "problemSolving": 2,
      "communication": 3,
      "cultureFit": 2,
      "overallRecommendation": "do_not_hire",
      "evaluationNotes": "Did not meet current technical or logistical criteria.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-09-28T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-09-28",
        "interviewStartTime": "11:00",
        "department": "Logistics & Administration",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹3,00,000 - ₹4,20,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "do_not_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-09-28T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-16T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Executive Fleet Driver. Status: rejected",
      "nextFollowUpDate": "2026-09-28",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹3,00,000 - ₹4,20,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-5",
          "candidateId": "cand-005",
          "candidateName": "Daleep",
          "candidatePhone": "+91 98290 12415",
          "jobTitle": "Supervisor (Civil)",
          "jobId": "job-supervisor-civil",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-09-16T09:30:00.000Z",
          "durationSeconds": 395,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Fleet Driver.",
          "followUpDate": "2026-09-28",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹3,00,000 - ₹4,20,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "newspaper",
            "Driver"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-5-r1",
        "action": "Round 1 Interview REJECTED",
        "details": "First round screening interview: Rejected",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-09-28T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-5-apply",
        "action": "Application Ingested via Newspaper AD",
        "details": "Resume received and processed for Executive Fleet Driver",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-16T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-006",
    "name": "Sonu Kumar",
    "email": "sonu.kumar@example.com",
    "phone": "+91 98290 12438",
    "location": "Jaipur, Rajasthan",
    "source": "newspaper",
    "sourceId": "NEWSPAPER-1006",
    "jobAppliedFor": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "department": "Civil & Construction",
    "appliedDate": "2026-09-19T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-01T10:00:00.000Z",
    "status": "joined",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Supervisor (Civil)",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹4,50,000 - ₹7,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "newspaper",
      "Supervisor (Civil)",
      "joined"
    ],
    "notes": "Joined",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-006",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-006.pdf",
    "resumeData": {
      "summary": "Results-driven Civil Supervisor with over 5 years of progressive experience delivering excellence in Civil & Construction. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Civil Construction",
        "RCC Structure Inspection",
        "Material Quality Check",
        "Labor Workforce Supervision",
        "Site Safety Audits",
        "Daily Progress Reporting (DPR)",
        "Vendor Billing"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Civil Supervisor - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Civil & Construction, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Civil Supervisor",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Construction Safety Officer (OSHA Standards)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Civil Supervisor",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Civil & Construction, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Joined",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-21T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-21",
        "interviewStartTime": "11:00",
        "department": "Civil & Construction",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹4,50,000 - ₹7,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Joined",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-21T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-19T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Civil Supervisor. Status: joined",
      "nextFollowUpDate": "2026-09-23",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹4,50,000 - ₹7,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-6",
          "candidateId": "cand-006",
          "candidateName": "Sonu Kumar",
          "candidatePhone": "+91 98290 12438",
          "jobTitle": "Supervisor (Civil)",
          "jobId": "job-supervisor-civil",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-19T09:30:00.000Z",
          "durationSeconds": 410,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Civil Supervisor.",
          "followUpDate": "2026-09-21",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹4,50,000 - ₹7,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "newspaper",
            "Supervisor (Civil)"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-6-join",
        "action": "Candidate Successfully Joined",
        "details": "Formally joined UrbanGaon on 2026-10-01. Welcome to the organization!",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-01T10:00:00.000Z",
        "type": "status"
      },
      {
        "id": "act-1791009676492-6-offer",
        "action": "Employment Offer Released",
        "details": "Offer approved and released. Position: Civil Supervisor",
        "performedBy": "Hiring Committee",
        "timestamp": "2026-10-01T08:00:00.000Z",
        "type": "status"
      },
      {
        "id": "act-1791009676492-6-r2",
        "action": "Round 2 Interview CLEARED",
        "details": "Evaluated by Technical & Leadership Panel: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-23T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-6-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-21T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-6-apply",
        "action": "Application Ingested via Newspaper AD",
        "details": "Resume received and processed for Civil Supervisor",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-19T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-007",
    "name": "Maneesh",
    "email": "maneesh@example.com",
    "phone": "+91 98290 12461",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1007",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "appliedDate": "2026-09-29T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-29T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 4,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "EA",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 7 for Executive Assistant (EA).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-007",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-007.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Assistant (EA) with over 4 years of progressive experience delivering excellence in Executive Office. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Executive Calendar Management",
        "Stakeholder Communication",
        "Travel Logistics",
        "Confidential Reporting",
        "Meeting Documentation",
        "ERP Operations",
        "Cross-functional Alignment"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Assistant (EA) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Executive Office, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Assistant (EA)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Assistant (EA)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Executive Office, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-29T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-29",
        "interviewStartTime": "11:00",
        "department": "Executive Office",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-29T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-29T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Executive Assistant (EA). Status: interview_r1",
      "nextFollowUpDate": "2026-09-29",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-7",
          "candidateId": "cand-007",
          "candidateName": "Maneesh",
          "candidatePhone": "+91 98290 12461",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-29T09:30:00.000Z",
          "durationSeconds": 425,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Executive Assistant (EA).",
          "followUpDate": "2026-09-29",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "EA"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-7-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-29T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-7-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Executive Assistant (EA)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-29T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-008",
    "name": "Shailendra",
    "email": "shailendra@example.com",
    "phone": "+91 98290 12484",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1008",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "appliedDate": "2026-09-29T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-29T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 4,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "EA",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 8 for Executive Assistant (EA).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-008",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-008.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Assistant (EA) with over 4 years of progressive experience delivering excellence in Executive Office. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Executive Calendar Management",
        "Stakeholder Communication",
        "Travel Logistics",
        "Confidential Reporting",
        "Meeting Documentation",
        "ERP Operations",
        "Cross-functional Alignment"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Assistant (EA) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Executive Office, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Assistant (EA)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Assistant (EA)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Executive Office, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-09-29T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-09-29",
        "interviewStartTime": "11:00",
        "department": "Executive Office",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-09-29T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-29T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Executive Assistant (EA). Status: interview_r1",
      "nextFollowUpDate": "2026-09-29",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-8",
          "candidateId": "cand-008",
          "candidateName": "Shailendra",
          "candidatePhone": "+91 98290 12484",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-09-29T09:30:00.000Z",
          "durationSeconds": 440,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Assistant (EA).",
          "followUpDate": "2026-09-29",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "EA"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-8-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-09-29T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-8-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Executive Assistant (EA)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-29T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-009",
    "name": "Dk Chawla",
    "email": "dk.chawla@example.com",
    "phone": "+91 98290 12507",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1009",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "appliedDate": "2026-09-29T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-29T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 4,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "EA",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 9 for Executive Assistant (EA).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-009",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-009.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Assistant (EA) with over 4 years of progressive experience delivering excellence in Executive Office. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Executive Calendar Management",
        "Stakeholder Communication",
        "Travel Logistics",
        "Confidential Reporting",
        "Meeting Documentation",
        "ERP Operations",
        "Cross-functional Alignment"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Assistant (EA) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Executive Office, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Assistant (EA)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Assistant (EA)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Executive Office, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-29T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-29",
        "interviewStartTime": "11:00",
        "department": "Executive Office",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-29T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-29T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Executive Assistant (EA). Status: interview_r1",
      "nextFollowUpDate": "2026-09-29",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-9",
          "candidateId": "cand-009",
          "candidateName": "Dk Chawla",
          "candidatePhone": "+91 98290 12507",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-29T09:30:00.000Z",
          "durationSeconds": 455,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Executive Assistant (EA).",
          "followUpDate": "2026-09-29",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "EA"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676492-9-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-29T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676492-9-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Executive Assistant (EA)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-29T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-010",
    "name": "Surya Mandotiya",
    "email": "surya.mandotiya@example.com",
    "phone": "+91 98290 12530",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1010",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "appliedDate": "2026-09-29T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-29T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 4,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "EA",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 10 for Executive Assistant (EA).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-010",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-010.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Assistant (EA) with over 4 years of progressive experience delivering excellence in Executive Office. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Executive Calendar Management",
        "Stakeholder Communication",
        "Travel Logistics",
        "Confidential Reporting",
        "Meeting Documentation",
        "ERP Operations",
        "Cross-functional Alignment"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Assistant (EA) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Executive Office, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Assistant (EA)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Assistant (EA)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Executive Office, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-29T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-29",
        "interviewStartTime": "11:00",
        "department": "Executive Office",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-29T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-29T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Executive Assistant (EA). Status: interview_r1",
      "nextFollowUpDate": "2026-09-29",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-10",
          "candidateId": "cand-010",
          "candidateName": "Surya Mandotiya",
          "candidatePhone": "+91 98290 12530",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-29T09:30:00.000Z",
          "durationSeconds": 470,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Executive Assistant (EA).",
          "followUpDate": "2026-09-29",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "EA"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-10-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-29T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-10-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Executive Assistant (EA)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-29T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-011",
    "name": "Dinesh",
    "email": "dinesh@example.com",
    "phone": "+91 98290 12553",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1011",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "appliedDate": "2026-09-29T09:30:00.000Z",
    "lastUpdatedDate": "2026-09-29T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 4,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "EA",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 11 for Executive Assistant (EA).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-011",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-011.pdf",
    "resumeData": {
      "summary": "Results-driven Executive Assistant (EA) with over 4 years of progressive experience delivering excellence in Executive Office. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Executive Calendar Management",
        "Stakeholder Communication",
        "Travel Logistics",
        "Confidential Reporting",
        "Meeting Documentation",
        "ERP Operations",
        "Cross-functional Alignment"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Executive Assistant (EA) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Executive Office, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Executive Assistant (EA)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Executive Assistant (EA)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Executive Office, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-09-29T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-09-29",
        "interviewStartTime": "11:00",
        "department": "Executive Office",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-09-29T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-29T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Executive Assistant (EA). Status: interview_r1",
      "nextFollowUpDate": "2026-09-29",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹6,00,000 - ₹9,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-11",
          "candidateId": "cand-011",
          "candidateName": "Dinesh",
          "candidatePhone": "+91 98290 12553",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-09-29T09:30:00.000Z",
          "durationSeconds": 485,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Assistant (EA).",
          "followUpDate": "2026-09-29",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "EA"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-11-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-09-29T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-11-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Executive Assistant (EA)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-29T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-012",
    "name": "Shilendra Saxena",
    "email": "shilendra.saxena@example.com",
    "phone": "+91 98290 12576",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1012",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-09-26T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-03T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "DPM",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 12 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-012",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-012.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-09-26T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-09-26",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-09-26T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-09-26T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r2",
      "nextFollowUpDate": "2026-10-03",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-12",
          "candidateId": "cand-012",
          "candidateName": "Shilendra Saxena",
          "candidatePhone": "+91 98290 12576",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-09-26T09:30:00.000Z",
          "durationSeconds": 500,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-09-26",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-12-r2",
        "action": "Round 2 Interview Scheduled (2026-10-03)",
        "details": "Scheduled for 2026-10-03 at 14:00 with Panel Lead",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-03T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-12-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-09-26T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-12-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-09-26T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-013",
    "name": "Vishvendra Singh",
    "email": "vishvendra.singh@example.com",
    "phone": "+91 98290 12599",
    "location": "Jaipur, Rajasthan",
    "source": "apna",
    "sourceId": "APNA-1013",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-03T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "apna",
      "DPM",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 13 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-013",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-013.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-01T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-01",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-01T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r2",
      "nextFollowUpDate": "2026-10-03",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-13",
          "candidateId": "cand-013",
          "candidateName": "Vishvendra Singh",
          "candidatePhone": "+91 98290 12599",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 515,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-10-01",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "apna",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-13-r2",
        "action": "Round 2 Interview Scheduled (2026-10-03)",
        "details": "Scheduled for 2026-10-03 at 14:00 with Panel Lead",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-03T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-13-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-01T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-13-apply",
        "action": "Application Ingested via Apna",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-014",
    "name": "Irshad Khokar",
    "email": "irshad.khokar@example.com",
    "phone": "+91 98290 12622",
    "location": "Jaipur, Rajasthan",
    "source": "apna",
    "sourceId": "APNA-1014",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T16:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "apna",
      "DPM",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 14 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-014",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-014.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-01T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-01",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-01T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: rejected",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-14",
          "candidateId": "cand-014",
          "candidateName": "Irshad Khokar",
          "candidatePhone": "+91 98290 12622",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 530,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-10-01",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "apna",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-14-r2",
        "action": "Round 2 Interview REJECTED",
        "details": "Evaluated by Technical & Leadership Panel: Rejected",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-14-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-14-apply",
        "action": "Application Ingested via Apna",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-015",
    "name": "Achin Sharma",
    "email": "achin.sharma@example.com",
    "phone": "+91 98290 12645",
    "location": "Jaipur, Rajasthan",
    "source": "apna",
    "sourceId": "APNA-1015",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-04T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "apna",
      "DPM",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 15 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-015",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-015.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-01T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-01",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-01T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r2",
      "nextFollowUpDate": "2026-10-04",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-15",
          "candidateId": "cand-015",
          "candidateName": "Achin Sharma",
          "candidatePhone": "+91 98290 12645",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 545,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-10-01",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "apna",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-15-r2",
        "action": "Round 2 Interview Scheduled (2026-10-04)",
        "details": "Scheduled for 2026-10-04 at 14:00 with Panel Lead",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-04T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-15-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-01T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-15-apply",
        "action": "Application Ingested via Apna",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-016",
    "name": "Arya Mishra",
    "email": "arya.mishra@example.com",
    "phone": "+91 98290 12668",
    "location": "Jaipur, Rajasthan",
    "source": "referral",
    "sourceId": "REFERRAL-1016",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-01T16:00:00.000Z",
    "status": "offered",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 3.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "referral",
      "Talent",
      "offered"
    ],
    "notes": "Candidate tracked under S.No 16 for Talent Acquisition Specialist.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-016",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-016.pdf",
    "resumeData": {
      "summary": "Results-driven Talent Acquisition Specialist with over 3.5 years of progressive experience delivering excellence in Human Resources. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "End-to-End Talent Sourcing",
        "Technical Recruitment",
        "Portal Screening (Naukri/Apna/LinkedIn)",
        "Candidate Pipeline Architecture",
        "Interview Coordination",
        "Offer Negotiation",
        "Onboarding Operations"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Talent Acquisition Specialist - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Human Resources, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Talent Acquisition Specialist",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Human Resources",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Talent Sourcing & HR Analytics Professional"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Talent Acquisition Specialist",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Human Resources, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-01T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-01",
        "interviewStartTime": "11:00",
        "department": "Human Resources",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-01T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Talent Acquisition Specialist. Status: offered",
      "nextFollowUpDate": "2026-10-01",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-16",
          "candidateId": "cand-016",
          "candidateName": "Arya Mishra",
          "candidatePhone": "+91 98290 12668",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 560,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Talent Acquisition Specialist.",
          "followUpDate": "2026-10-01",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹5,50,000 - ₹8,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "referral",
            "Talent"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-16-offer",
        "action": "Employment Offer Released",
        "details": "Offer approved and released. Position: Talent Acquisition Specialist",
        "performedBy": "Hiring Committee",
        "timestamp": "2026-10-01T17:00:00.000Z",
        "type": "status"
      },
      {
        "id": "act-1791009676493-16-r2",
        "action": "Round 2 Interview CLEARED",
        "details": "Evaluated by Technical & Leadership Panel: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-16-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-16-apply",
        "action": "Application Ingested via Referrals",
        "details": "Resume received and processed for Talent Acquisition Specialist",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-017",
    "name": "Aastha Sharma",
    "email": "aastha.sharma@example.com",
    "phone": "+91 98290 12691",
    "location": "Jaipur, Rajasthan",
    "source": "referral",
    "sourceId": "REFERRAL-1017",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-01T16:00:00.000Z",
    "status": "offered",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 3.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "referral",
      "Talent",
      "offered"
    ],
    "notes": "Candidate tracked under S.No 17 for Talent Acquisition Specialist.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-017",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-017.pdf",
    "resumeData": {
      "summary": "Results-driven Talent Acquisition Specialist with over 3.5 years of progressive experience delivering excellence in Human Resources. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "End-to-End Talent Sourcing",
        "Technical Recruitment",
        "Portal Screening (Naukri/Apna/LinkedIn)",
        "Candidate Pipeline Architecture",
        "Interview Coordination",
        "Offer Negotiation",
        "Onboarding Operations"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Talent Acquisition Specialist - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Human Resources, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Talent Acquisition Specialist",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Human Resources",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Talent Sourcing & HR Analytics Professional"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Talent Acquisition Specialist",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Human Resources, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-01T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-01",
        "interviewStartTime": "11:00",
        "department": "Human Resources",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-01T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Talent Acquisition Specialist. Status: offered",
      "nextFollowUpDate": "2026-10-01",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-17",
          "candidateId": "cand-017",
          "candidateName": "Aastha Sharma",
          "candidatePhone": "+91 98290 12691",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 575,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Talent Acquisition Specialist.",
          "followUpDate": "2026-10-01",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹5,50,000 - ₹8,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "referral",
            "Talent"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-17-offer",
        "action": "Employment Offer Released",
        "details": "Offer approved and released. Position: Talent Acquisition Specialist",
        "performedBy": "Hiring Committee",
        "timestamp": "2026-10-01T17:00:00.000Z",
        "type": "status"
      },
      {
        "id": "act-1791009676493-17-r2",
        "action": "Round 2 Interview CLEARED",
        "details": "Evaluated by Technical & Leadership Panel: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-17-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-17-apply",
        "action": "Application Ingested via Referrals",
        "details": "Resume received and processed for Talent Acquisition Specialist",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-018",
    "name": "Satyaveer Singh Shekhawat",
    "email": "satyaveer.singh.shekhawat@example.com",
    "phone": "+91 98290 12714",
    "location": "Jaipur, Rajasthan",
    "source": "referral",
    "sourceId": "REFERRAL-1018",
    "jobAppliedFor": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T10:00:00.000Z",
    "status": "joined",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 3.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "EA to Director",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "referral",
      "Talent",
      "joined"
    ],
    "notes": "Joined",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-018",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-018.pdf",
    "resumeData": {
      "summary": "Results-driven Talent Acquisition Specialist with over 3.5 years of progressive experience delivering excellence in Human Resources. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "End-to-End Talent Sourcing",
        "Technical Recruitment",
        "Portal Screening (Naukri/Apna/LinkedIn)",
        "Candidate Pipeline Architecture",
        "Interview Coordination",
        "Offer Negotiation",
        "Onboarding Operations"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Talent Acquisition Specialist - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Human Resources, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Talent Acquisition Specialist",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Human Resources",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Talent Sourcing & HR Analytics Professional"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Talent Acquisition Specialist",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Human Resources, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Joined",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-01T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-01",
        "interviewStartTime": "11:00",
        "department": "Human Resources",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Joined",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-01T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Talent Acquisition Specialist. Status: joined",
      "nextFollowUpDate": "2026-10-01",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹5,50,000 - ₹8,50,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-18",
          "candidateId": "cand-018",
          "candidateName": "Satyaveer Singh Shekhawat",
          "candidatePhone": "+91 98290 12714",
          "jobTitle": "EA to Director",
          "jobId": "job-ea-director",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 590,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Talent Acquisition Specialist.",
          "followUpDate": "2026-10-01",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹5,50,000 - ₹8,50,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "referral",
            "Talent"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-18-join",
        "action": "Candidate Successfully Joined",
        "details": "Formally joined UrbanGaon on 2026-10-02. Welcome to the organization!",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T10:00:00.000Z",
        "type": "status"
      },
      {
        "id": "act-1791009676493-18-offer",
        "action": "Employment Offer Released",
        "details": "Offer approved and released. Position: Talent Acquisition Specialist",
        "performedBy": "Hiring Committee",
        "timestamp": "2026-10-02T08:00:00.000Z",
        "type": "status"
      },
      {
        "id": "act-1791009676493-18-r2",
        "action": "Round 2 Interview CLEARED",
        "details": "Evaluated by Technical & Leadership Panel: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-18-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-01T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-18-apply",
        "action": "Application Ingested via Referrals",
        "details": "Resume received and processed for Talent Acquisition Specialist",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-019",
    "name": "Yudhishtir Yadav",
    "email": "yudhishtir.yadav@example.com",
    "phone": "+91 98290 12737",
    "location": "Jaipur, Rajasthan",
    "source": "apna",
    "sourceId": "APNA-1019",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-03T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "apna",
      "DPM",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 19 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-019",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-019.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r2",
      "nextFollowUpDate": "2026-10-03",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-19",
          "candidateId": "cand-019",
          "candidateName": "Yudhishtir Yadav",
          "candidatePhone": "+91 98290 12737",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 605,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "apna",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-19-r2",
        "action": "Round 2 Interview Scheduled (2026-10-03)",
        "details": "Scheduled for 2026-10-03 at 14:00 with Panel Lead",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-03T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-19-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-19-apply",
        "action": "Application Ingested via Apna",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-020",
    "name": "Rohit Varma",
    "email": "rohit.varma@example.com",
    "phone": "+91 98290 12760",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1020",
    "jobAppliedFor": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T12:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 62,
    "rating": 2,
    "experienceYears": 5.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Assistant Manager – Sales",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Sales& Marketing",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 20 for Sales & Marketing Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-020",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-020.pdf",
    "resumeData": {
      "summary": "Results-driven Sales & Marketing Manager with over 5.5 years of progressive experience delivering excellence in Sales & Marketing. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Real Estate Sales & Closures",
        "Channel Partner Alliances",
        "Direct Client Acquisition",
        "Market Penetration Strategy",
        "Revenue Target Achievement",
        "CRM Management",
        "Lead Pipeline Nurturing"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Sales & Marketing Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Sales & Marketing, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Sales & Marketing Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Marketing & Business Administration",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Strategic Real Estate Sales Leader"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Sales & Marketing Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Sales & Marketing, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 2,
      "problemSolving": 2,
      "communication": 3,
      "cultureFit": 2,
      "overallRecommendation": "do_not_hire",
      "evaluationNotes": "Did not meet current technical or logistical criteria.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Sales & Marketing",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "do_not_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Sales & Marketing Manager. Status: rejected",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-20",
          "candidateId": "cand-020",
          "candidateName": "Rohit Varma",
          "candidatePhone": "+91 98290 12760",
          "jobTitle": "Assistant Manager – Sales",
          "jobId": "job-am-sales",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 620,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Sales & Marketing Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Sales& Marketing"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-20-r1",
        "action": "Round 1 Interview REJECTED",
        "details": "First round screening interview: Rejected",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-20-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Sales & Marketing Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-021",
    "name": "Ashish Jangir",
    "email": "ashish.jangir@example.com",
    "phone": "+91 98290 12783",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1021",
    "jobAppliedFor": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 86,
    "rating": 4,
    "experienceYears": 5.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Assistant Manager – Sales",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Sales& Marketing",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 21 for Sales & Marketing Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-021",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-021.pdf",
    "resumeData": {
      "summary": "Results-driven Sales & Marketing Manager with over 5.5 years of progressive experience delivering excellence in Sales & Marketing. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Real Estate Sales & Closures",
        "Channel Partner Alliances",
        "Direct Client Acquisition",
        "Market Penetration Strategy",
        "Revenue Target Achievement",
        "CRM Management",
        "Lead Pipeline Nurturing"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Sales & Marketing Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Sales & Marketing, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Sales & Marketing Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Marketing & Business Administration",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Strategic Real Estate Sales Leader"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Sales & Marketing Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Sales & Marketing, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 4,
      "problemSolving": 4,
      "communication": 4,
      "cultureFit": 4,
      "overallRecommendation": "hire",
      "evaluationNotes": "Progressing through evaluation pipeline.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Sales & Marketing",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Sales & Marketing Manager. Status: interview_r1",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "connected",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-21",
          "candidateId": "cand-021",
          "candidateName": "Ashish Jangir",
          "candidatePhone": "+91 98290 12783",
          "jobTitle": "Assistant Manager – Sales",
          "jobId": "job-am-sales",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 635,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Sales & Marketing Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Sales& Marketing"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-21-r1",
        "action": "Round 1 Interview Scheduled (2026-10-02)",
        "details": "Interview scheduled on 2026-10-02",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-21-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Sales & Marketing Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-022",
    "name": "Shivam Upadhyay",
    "email": "shivam.upadhyay@example.com",
    "phone": "+91 98290 12806",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1022",
    "jobAppliedFor": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-03T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 5.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Assistant Manager – Sales",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Sales& Marketing",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 22 for Sales & Marketing Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-022",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-022.pdf",
    "resumeData": {
      "summary": "Results-driven Sales & Marketing Manager with over 5.5 years of progressive experience delivering excellence in Sales & Marketing. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Real Estate Sales & Closures",
        "Channel Partner Alliances",
        "Direct Client Acquisition",
        "Market Penetration Strategy",
        "Revenue Target Achievement",
        "CRM Management",
        "Lead Pipeline Nurturing"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Sales & Marketing Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Sales & Marketing, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Sales & Marketing Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Marketing & Business Administration",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Strategic Real Estate Sales Leader"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Sales & Marketing Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Sales & Marketing, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Sales & Marketing",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Sales & Marketing Manager. Status: interview_r2",
      "nextFollowUpDate": "2026-10-03",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-22",
          "candidateId": "cand-022",
          "candidateName": "Shivam Upadhyay",
          "candidatePhone": "+91 98290 12806",
          "jobTitle": "Assistant Manager – Sales",
          "jobId": "job-am-sales",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 650,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Sales & Marketing Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Sales& Marketing"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-22-r2",
        "action": "Round 2 Interview Scheduled (2026-10-03)",
        "details": "Scheduled for 2026-10-03 at 14:00 with Panel Lead",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-03T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-22-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-22-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Sales & Marketing Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-023",
    "name": "Rohit Sood",
    "email": "rohit.sood@example.com",
    "phone": "+91 98290 12829",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1023",
    "jobAppliedFor": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-03T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 5.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Assistant Manager – Sales",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Sales& Marketing",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 23 for Sales & Marketing Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-023",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-023.pdf",
    "resumeData": {
      "summary": "Results-driven Sales & Marketing Manager with over 5.5 years of progressive experience delivering excellence in Sales & Marketing. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Real Estate Sales & Closures",
        "Channel Partner Alliances",
        "Direct Client Acquisition",
        "Market Penetration Strategy",
        "Revenue Target Achievement",
        "CRM Management",
        "Lead Pipeline Nurturing"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Sales & Marketing Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Sales & Marketing, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Sales & Marketing Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Marketing & Business Administration",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Strategic Real Estate Sales Leader"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Sales & Marketing Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Sales & Marketing, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Sales & Marketing",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Sales & Marketing Manager. Status: interview_r2",
      "nextFollowUpDate": "2026-10-03",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-23",
          "candidateId": "cand-023",
          "candidateName": "Rohit Sood",
          "candidatePhone": "+91 98290 12829",
          "jobTitle": "Assistant Manager – Sales",
          "jobId": "job-am-sales",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 665,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Sales & Marketing Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Sales& Marketing"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-23-r2",
        "action": "Round 2 Interview Scheduled (2026-10-03)",
        "details": "Scheduled for 2026-10-03 at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-03T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-23-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-23-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Sales & Marketing Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-024",
    "name": "Virendra Kumar Jain",
    "email": "virendra.kumar.jain@example.com",
    "phone": "+91 98290 12852",
    "location": "Jaipur, Rajasthan",
    "source": "referral",
    "sourceId": "REFERRAL-1024",
    "jobAppliedFor": "Project Manager",
    "jobId": "job-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-01T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-04T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 10,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹18,00,000 - ₹25,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "referral",
      "Project Manager",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 24 for Senior Project Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-024",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-024.pdf",
    "resumeData": {
      "summary": "Results-driven Senior Project Manager with over 10 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Mega-Scale Project Delivery",
        "Budget Management & P&L",
        "EPC Contractor Oversight",
        "Risk Management",
        "Regulatory Clearance Compliance",
        "BIM Architecture Alignment",
        "Resource Optimization"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Senior Project Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Senior Project Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Senior Project Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹18,00,000 - ₹25,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-01T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Senior Project Manager. Status: interview_r2",
      "nextFollowUpDate": "2026-10-04",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹18,00,000 - ₹25,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-24",
          "candidateId": "cand-024",
          "candidateName": "Virendra Kumar Jain",
          "candidatePhone": "+91 98290 12852",
          "jobTitle": "Project Manager",
          "jobId": "job-project-manager",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-01T09:30:00.000Z",
          "durationSeconds": 680,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Senior Project Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹18,00,000 - ₹25,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "referral",
            "Project Manager"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-24-r2",
        "action": "Round 2 Interview Scheduled (2026-10-04)",
        "details": "Scheduled for 2026-10-04 at 14:00 with Panel Lead",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-04T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-24-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-24-apply",
        "action": "Application Ingested via Referrals",
        "details": "Resume received and processed for Senior Project Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-01T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-025",
    "name": "Deepak Sambhwani",
    "email": "deepak.sambhwani@example.com",
    "phone": "+91 98290 12875",
    "location": "Jaipur, Rajasthan",
    "source": "referral",
    "sourceId": "REFERRAL-1025",
    "jobAppliedFor": "Purchase Manager – Construction Procurement",
    "jobId": "job-purchase-manager-construction",
    "department": "Procurement & Purchase",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T12:00:00.000Z",
    "status": "interview_r1",
    "atsMatchScore": 86,
    "rating": 4,
    "experienceYears": 7.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Purchase Manager – Construction Procurement",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹10,00,000 - ₹15,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "referral",
      "Purchase Manager – Construction Procurement",
      "interview_r1"
    ],
    "notes": "Candidate tracked under S.No 25 for Purchase Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-025",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-025.pdf",
    "resumeData": {
      "summary": "Results-driven Purchase Manager with over 7.5 years of progressive experience delivering excellence in Procurement & Purchase. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Strategic Procurement",
        "Vendor Negotiations",
        "Supply Chain Auditing",
        "Raw Material Sourcing (Steel/Cement/Equip)",
        "PO Management",
        "Cost Reductions",
        "Inventory Optimization"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Purchase Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Procurement & Purchase, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Purchase Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Business Administration (BBA)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Advanced Professional Operations & Compliance Certification"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Purchase Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Procurement & Purchase, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 4,
      "problemSolving": 4,
      "communication": 4,
      "cultureFit": 4,
      "overallRecommendation": "hire",
      "evaluationNotes": "Progressing through evaluation pipeline.",
      "evaluatedBy": "Satyaveer Singh",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Satyaveer Singh",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Procurement & Purchase",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹10,00,000 - ₹15,00,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Satyaveer Singh",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Purchase Manager. Status: interview_r1",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "connected",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹10,00,000 - ₹15,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-25",
          "candidateId": "cand-025",
          "candidateName": "Deepak Sambhwani",
          "candidatePhone": "+91 98290 12875",
          "jobTitle": "Purchase Manager – Construction Procurement",
          "jobId": "job-purchase-manager-construction",
          "recruiterName": "Satyaveer Singh",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 695,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Purchase Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹10,00,000 - ₹15,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "referral",
            "Purchase Manager – Construction Procurement"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-25-r1",
        "action": "Round 1 Interview Scheduled (2026-10-02)",
        "details": "Interview scheduled on 2026-10-02",
        "performedBy": "Satyaveer Singh",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-25-apply",
        "action": "Application Ingested via Referrals",
        "details": "Resume received and processed for Purchase Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-026",
    "name": "Rakesh Kuma Jangid",
    "email": "rakesh.kuma.jangid@example.com",
    "phone": "+91 98290 12898",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1026",
    "jobAppliedFor": "Project Manager",
    "jobId": "job-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T12:00:00.000Z",
    "status": "rejected",
    "atsMatchScore": 62,
    "rating": 2,
    "experienceYears": 10,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹18,00,000 - ₹25,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Project Manager",
      "rejected"
    ],
    "notes": "Candidate tracked under S.No 26 for Senior Project Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-026",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-026.pdf",
    "resumeData": {
      "summary": "Results-driven Senior Project Manager with over 10 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Mega-Scale Project Delivery",
        "Budget Management & P&L",
        "EPC Contractor Oversight",
        "Risk Management",
        "Regulatory Clearance Compliance",
        "BIM Architecture Alignment",
        "Resource Optimization"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Senior Project Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Senior Project Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Senior Project Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 2,
      "problemSolving": 2,
      "communication": 3,
      "cultureFit": 2,
      "overallRecommendation": "do_not_hire",
      "evaluationNotes": "Did not meet current technical or logistical criteria.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹18,00,000 - ₹25,00,000 P.A.",
        "coreValues": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 3,
          "yt": 3,
          "ss": 3,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 4,
          "yt": 3,
          "ss": 4,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 2,
          "yt": 2,
          "ss": 2,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 2,
          "yt": 3,
          "ss": 2,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "Misalignment on core technical requirements",
          "Location/Notice constraints",
          "Compensation outside approved band"
        ],
        "overallRecommendation": "do_not_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_failed",
      "lastCallNotes": "Candidate screened for Senior Project Manager. Status: rejected",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "disqualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹18,00,000 - ₹25,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-26",
          "candidateId": "cand-026",
          "candidateName": "Rakesh Kuma Jangid",
          "candidatePhone": "+91 98290 12898",
          "jobTitle": "Project Manager",
          "jobId": "job-project-manager",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 710,
          "disposition": "connected_screening_failed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Project Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹18,00,000 - ₹25,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Project Manager"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-26-r1",
        "action": "Round 1 Interview REJECTED",
        "details": "First round screening interview: Rejected",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-26-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Senior Project Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-027",
    "name": "Vikas Saini",
    "email": "vikas.saini@example.com",
    "phone": "+91 98290 12921",
    "location": "Jaipur, Rajasthan",
    "source": "apna",
    "sourceId": "APNA-1027",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-03T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "apna",
      "DPM",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 27 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-027",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-027.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r2",
      "nextFollowUpDate": "2026-10-03",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-27",
          "candidateId": "cand-027",
          "candidateName": "Vikas Saini",
          "candidatePhone": "+91 98290 12921",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 725,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "apna",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-27-r2",
        "action": "Round 2 Interview Scheduled (2026-10-03)",
        "details": "Scheduled for 2026-10-03 at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-03T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-27-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-27-apply",
        "action": "Application Ingested via Apna",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-028",
    "name": "Ashish Agrawal",
    "email": "ashish.agrawal@example.com",
    "phone": "+91 98290 12944",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1028",
    "jobAppliedFor": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T12:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Head of Architecture",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Architect",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 28 for Senior Design Architect.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-028",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-028.pdf",
    "resumeData": {
      "summary": "Results-driven Senior Design Architect with over 6.5 years of progressive experience delivering excellence in Architecture & Design. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Master Planning & Urban Architecture",
        "AutoCAD & Revit 3D",
        "Sustainable Architectural Design",
        "Structural Feasibility",
        "Client Presentations",
        "Façade Detailing",
        "Municipal Approval Clearances"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Senior Design Architect - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Architecture & Design, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Senior Design Architect",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Architecture (B.Arch)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Council of Architecture (COA) Registered Architect"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Senior Design Architect",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Architecture & Design, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Architecture & Design",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Senior Design Architect. Status: interview_r2",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-28",
          "candidateId": "cand-028",
          "candidateName": "Ashish Agrawal",
          "candidatePhone": "+91 98290 12944",
          "jobTitle": "Head of Architecture",
          "jobId": "job-head-architecture",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 740,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Design Architect.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Architect"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-28-r2",
        "action": "Round 2 Interview Scheduled (Pending)",
        "details": "Scheduled for Pending at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-28-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-28-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Senior Design Architect",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-029",
    "name": "Md. Wasim",
    "email": "md.wasim@example.com",
    "phone": "+91 98290 12967",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1029",
    "jobAppliedFor": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-10T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Head of Architecture",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Architect",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 29 for Senior Design Architect.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-029",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-029.pdf",
    "resumeData": {
      "summary": "Results-driven Senior Design Architect with over 6.5 years of progressive experience delivering excellence in Architecture & Design. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Master Planning & Urban Architecture",
        "AutoCAD & Revit 3D",
        "Sustainable Architectural Design",
        "Structural Feasibility",
        "Client Presentations",
        "Façade Detailing",
        "Municipal Approval Clearances"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Senior Design Architect - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Architecture & Design, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Senior Design Architect",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Architecture (B.Arch)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Council of Architecture (COA) Registered Architect"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Senior Design Architect",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Architecture & Design, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Architecture & Design",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Senior Design Architect. Status: interview_r2",
      "nextFollowUpDate": "2026-10-10",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-29",
          "candidateId": "cand-029",
          "candidateName": "Md. Wasim",
          "candidatePhone": "+91 98290 12967",
          "jobTitle": "Head of Architecture",
          "jobId": "job-head-architecture",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 755,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Design Architect.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Architect"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-29-r2",
        "action": "Round 2 Interview Scheduled (2026-10-10)",
        "details": "Scheduled for 2026-10-10 at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-10T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-29-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-29-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Senior Design Architect",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-030",
    "name": "Sushant Kumar",
    "email": "sushant.kumar@example.com",
    "phone": "+91 98290 12990",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1030",
    "jobAppliedFor": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-04T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Head of Architecture",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Architect",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 30 for Senior Design Architect.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-030",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-030.pdf",
    "resumeData": {
      "summary": "Results-driven Senior Design Architect with over 6.5 years of progressive experience delivering excellence in Architecture & Design. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Master Planning & Urban Architecture",
        "AutoCAD & Revit 3D",
        "Sustainable Architectural Design",
        "Structural Feasibility",
        "Client Presentations",
        "Façade Detailing",
        "Municipal Approval Clearances"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Senior Design Architect - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Architecture & Design, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Senior Design Architect",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Architecture (B.Arch)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Council of Architecture (COA) Registered Architect"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Senior Design Architect",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Architecture & Design, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Architecture & Design",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Senior Design Architect. Status: interview_r2",
      "nextFollowUpDate": "2026-10-04",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-30",
          "candidateId": "cand-030",
          "candidateName": "Sushant Kumar",
          "candidatePhone": "+91 98290 12990",
          "jobTitle": "Head of Architecture",
          "jobId": "job-head-architecture",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 770,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Design Architect.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Architect"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-30-r2",
        "action": "Round 2 Interview Scheduled (2026-10-04)",
        "details": "Scheduled for 2026-10-04 at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-04T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-30-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-30-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Senior Design Architect",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-031",
    "name": "Vijay Kalra",
    "email": "vijay.kalra@example.com",
    "phone": "+91 98290 13013",
    "location": "Jaipur, Rajasthan",
    "source": "naukri",
    "sourceId": "NAUKRI-1031",
    "jobAppliedFor": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-02T12:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 5.5,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Assistant Manager – Sales",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "naukri",
      "Sales& Marketing",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 31 for Sales & Marketing Manager.",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-031",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-031.pdf",
    "resumeData": {
      "summary": "Results-driven Sales & Marketing Manager with over 5.5 years of progressive experience delivering excellence in Sales & Marketing. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Real Estate Sales & Closures",
        "Channel Partner Alliances",
        "Direct Client Acquisition",
        "Market Penetration Strategy",
        "Revenue Target Achievement",
        "CRM Management",
        "Lead Pipeline Nurturing"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Sales & Marketing Manager - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Sales & Marketing, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Sales & Marketing Manager",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "MBA in Marketing & Business Administration",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Certified Strategic Real Estate Sales Leader"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Sales & Marketing Manager",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Sales & Marketing, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Sales & Marketing",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Sales & Marketing Manager. Status: interview_r2",
      "nextFollowUpDate": "2026-10-02",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹8,00,000 - ₹14,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-31",
          "candidateId": "cand-031",
          "candidateName": "Vijay Kalra",
          "candidatePhone": "+91 98290 13013",
          "jobTitle": "Assistant Manager – Sales",
          "jobId": "job-am-sales",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 785,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Sales & Marketing Manager.",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "naukri",
            "Sales& Marketing"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-31-r2",
        "action": "Round 2 Interview Scheduled (Pending)",
        "details": "Scheduled for Pending at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-31-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-31-apply",
        "action": "Application Ingested via Naukri",
        "details": "Resume received and processed for Sales & Marketing Manager",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  },
  {
    "id": "cand-032",
    "name": "Mohammed Faruk",
    "email": "mohammed.faruk@example.com",
    "phone": "+91 98290 13036",
    "location": "Jaipur, Rajasthan",
    "source": "apna",
    "sourceId": "APNA-1032",
    "jobAppliedFor": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "appliedDate": "2026-10-02T09:30:00.000Z",
    "lastUpdatedDate": "2026-10-04T16:00:00.000Z",
    "status": "interview_r2",
    "atsMatchScore": 94,
    "rating": 5,
    "experienceYears": 6,
    "currentCompany": "Apex Infrastructure Group",
    "currentDesignation": "Deputy Project Manager",
    "currentSalary": "₹8,50,000 P.A.",
    "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
    "noticePeriod": "30 Days",
    "recruiterAssigned": "Satyaveer Singh",
    "tags": [
      "apna",
      "DPM",
      "interview_r2"
    ],
    "notes": "Candidate tracked under S.No 32 for Deputy Project Manager (DPM).",
    "profileUrl": "https://urbangaon.recruitment/candidates/cand-032",
    "resumeUrl": "https://urbangaon.recruitment/resumes/cand-032.pdf",
    "resumeData": {
      "summary": "Results-driven Deputy Project Manager (DPM) with over 6 years of progressive experience delivering excellence in Project Management. Demonstrates strong operational acumen, strategic problem solving, and rigorous attention to detail aligned with organizational growth objectives.",
      "skills": [
        "Project Scheduling",
        "Primavera P6",
        "MS Project",
        "Site Execution",
        "Contractor Management",
        "Cost Optimization",
        "Quality Assurance",
        "Safety Compliance"
      ],
      "experience": [
        {
          "company": "Premier Infrastructure & Enterprise Solutions Ltd",
          "role": "Deputy Project Manager (DPM) - Lead",
          "duration": "2023 - Present",
          "location": "Jaipur / Delhi NCR",
          "highlights": [
            "Spearheaded core operations in Project Management, achieving a 22% increase in project delivery efficiency.",
            "Streamlined multi-stakeholder workflows and introduced standardized quality benchmarks.",
            "Supervised cross-functional teams, vendor alliances, and executive operational reporting."
          ]
        },
        {
          "company": "Apex Horizon Group",
          "role": "Associate Deputy Project Manager (DPM)",
          "duration": "2020 - 2023",
          "location": "Jaipur, Rajasthan",
          "highlights": [
            "Managed end-to-end milestone lifecycles while strictly adhering to budgets and safety schedules.",
            "Successfully optimized vendor turnaround times by 18% through automated workflow tracking."
          ]
        }
      ],
      "education": [
        {
          "degree": "Bachelor of Technology (Civil Engineering)",
          "institution": "University of Rajasthan / Premier Institute",
          "year": "2019",
          "grade": "First Division (Honours)"
        }
      ],
      "certifications": [
        "Project Management Professional (PMP)"
      ],
      "projects": [
        {
          "title": "Enterprise Milestone Delivery - Deputy Project Manager (DPM)",
          "desc": "Orchestrated high-impact strategic deliverables for large-scale operations in Project Management, recognized for outstanding execution speed and accuracy.",
          "link": "https://urbangaon.com/projects"
        }
      ],
      "languages": [
        "Hindi (Native / Fluent)",
        "English (Professional Working)"
      ]
    },
    "scorecard": {
      "technical": 5,
      "problemSolving": 5,
      "communication": 5,
      "cultureFit": 5,
      "overallRecommendation": "strong_hire",
      "evaluationNotes": "Demonstrated exceptional competence, domain command, and alignment.",
      "evaluatedBy": "Dr Sharmila Yadav",
      "evaluatedAt": "2026-10-02T12:00:00.000Z",
      "detailed": {
        "conductedBy": "Dr Sharmila Yadav",
        "interviewDate": "2026-10-02",
        "interviewStartTime": "11:00",
        "department": "Project Management",
        "currentSalary": "As per industry standard",
        "expectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
        "coreValues": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Integrity and alignment"
        },
        "personality": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Positive demeanor"
        },
        "communication": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Articulate responses"
        },
        "adaptability": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Adaptable to site operations"
        },
        "technical": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Domain knowledge"
        },
        "overallImpression": {
          "rp": 5,
          "yt": 5,
          "ss": 5,
          "comments": "Panel consensus"
        },
        "positives": [
          "Strong functional experience",
          "Clarity of past achievements",
          "Immediate operational readiness"
        ],
        "negatives": [
          "None identified",
          "None identified",
          "None identified"
        ],
        "overallRecommendation": "strong_hire",
        "finalComments": "Detailed evaluation completed.",
        "evaluatedBy": "Dr Sharmila Yadav",
        "evaluatedAt": "2026-10-02T12:00:00.000Z"
      }
    },
    "callingDetails": {
      "totalCalls": 1,
      "lastCallTime": "2026-10-02T09:30:00.000Z",
      "lastDisposition": "connected_screening_passed",
      "lastCallNotes": "Candidate screened for Deputy Project Manager (DPM). Status: interview_r2",
      "nextFollowUpDate": "2026-10-04",
      "nextFollowUpTime": "11:00",
      "callStatus": "qualified",
      "confirmedCurrentSalary": "₹8,50,000 P.A.",
      "confirmedExpectedSalary": "₹12,00,000 - ₹18,00,000 P.A.",
      "confirmedNoticePeriod": "30 Days",
      "isNegotiable": "yes",
      "confirmedLocation": "Jaipur, Rajasthan",
      "callHistory": [
        {
          "id": "call-rec-32",
          "candidateId": "cand-032",
          "candidateName": "Mohammed Faruk",
          "candidatePhone": "+91 98290 13036",
          "jobTitle": "Deputy Project Manager",
          "jobId": "job-deputy-project-manager",
          "recruiterName": "Dr Sharmila Yadav",
          "callTime": "2026-10-02T09:30:00.000Z",
          "durationSeconds": 800,
          "disposition": "connected_screening_passed",
          "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Deputy Project Manager (DPM).",
          "followUpDate": "2026-10-02",
          "followUpTime": "11:00",
          "confirmedCurrentCtc": "₹8,50,000 P.A.",
          "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
          "confirmedNoticePeriod": "30 Days",
          "isNegotiable": "yes",
          "confirmedLocation": "Jaipur, Rajasthan",
          "tags": [
            "apna",
            "DPM"
          ]
        }
      ]
    },
    "isCallingQueued": false,
    "isSalaryNegotiable": "yes",
    "activityHistory": [
      {
        "id": "act-1791009676493-32-r2",
        "action": "Round 2 Interview Scheduled (2026-10-04)",
        "details": "Scheduled for 2026-10-04 at 14:00 with Panel Lead",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-04T15:30:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-32-r1",
        "action": "Round 1 Interview CLEARED",
        "details": "First round screening interview: Cleared",
        "performedBy": "Dr Sharmila Yadav",
        "timestamp": "2026-10-02T11:00:00.000Z",
        "type": "interview"
      },
      {
        "id": "act-1791009676493-32-apply",
        "action": "Application Ingested via Apna",
        "details": "Resume received and processed for Deputy Project Manager (DPM)",
        "performedBy": "Automated Ingestion Pipeline",
        "timestamp": "2026-10-02T09:30:00.000Z",
        "type": "ingestion"
      }
    ]
  }
];

export const INITIAL_INTERVIEWS: InterviewSchedule[] = [
  {
    "id": "int-101",
    "candidateId": "cand-001",
    "candidateName": "Naveen",
    "candidateEmail": "naveen@example.com",
    "candidatePhone": "+91 98290 12323",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-21",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-1",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-09-18T09:30:00.000Z",
    "updatedAt": "2026-09-21T12:00:00.000Z"
  },
  {
    "id": "int-102",
    "candidateId": "cand-002",
    "candidateName": "Sushmita Tailang",
    "candidateEmail": "sushmita.tailang@example.com",
    "candidatePhone": "+91 98290 12346",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-21",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-2",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Rejected",
    "atsMatchScore": 62,
    "tags": [
      "EA",
      "Round 1"
    ],
    "createdAt": "2026-09-19T09:30:00.000Z",
    "updatedAt": "2026-09-21T12:00:00.000Z"
  },
  {
    "id": "int-103",
    "candidateId": "cand-003",
    "candidateName": "Ram Sahu",
    "candidateEmail": "ram.sahu@example.com",
    "candidatePhone": "+91 98290 12369",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-26",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-3",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Rejected",
    "atsMatchScore": 62,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-09-17T09:30:00.000Z",
    "updatedAt": "2026-09-26T12:00:00.000Z"
  },
  {
    "id": "int-104",
    "candidateId": "cand-004",
    "candidateName": "Gaurav Kumar Goyal",
    "candidateEmail": "gaurav.kumar.goyal@example.com",
    "candidatePhone": "+91 98290 12392",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-26",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-4",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Rejected",
    "atsMatchScore": 62,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-09-17T09:30:00.000Z",
    "updatedAt": "2026-09-26T12:00:00.000Z"
  },
  {
    "id": "int-105",
    "candidateId": "cand-005",
    "candidateName": "Daleep",
    "candidateEmail": "daleep@example.com",
    "candidatePhone": "+91 98290 12415",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "department": "Logistics & Administration",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-28",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-5",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Rejected",
    "atsMatchScore": 62,
    "tags": [
      "Driver",
      "Round 1"
    ],
    "createdAt": "2026-09-16T09:30:00.000Z",
    "updatedAt": "2026-09-28T12:00:00.000Z"
  },
  {
    "id": "int-106",
    "candidateId": "cand-006",
    "candidateName": "Sonu Kumar",
    "candidateEmail": "sonu.kumar@example.com",
    "candidatePhone": "+91 98290 12438",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "department": "Civil & Construction",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-21",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-6",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Supervisor (Civil)",
      "Round 1"
    ],
    "createdAt": "2026-09-19T09:30:00.000Z",
    "updatedAt": "2026-09-21T12:00:00.000Z"
  },
  {
    "id": "int-107",
    "candidateId": "cand-006",
    "candidateName": "Sonu Kumar",
    "candidateEmail": "sonu.kumar@example.com",
    "candidatePhone": "+91 98290 12438",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "department": "Civil & Construction",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-09-23",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R2 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Supervisor (Civil)",
      "Round 2"
    ],
    "createdAt": "2026-09-21T14:00:00.000Z",
    "updatedAt": "2026-09-23T15:00:00.000Z"
  },
  {
    "id": "int-108",
    "candidateId": "cand-007",
    "candidateName": "Maneesh",
    "candidateEmail": "maneesh@example.com",
    "candidatePhone": "+91 98290 12461",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-29",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-7",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "EA",
      "Round 1"
    ],
    "createdAt": "2026-09-29T09:30:00.000Z",
    "updatedAt": "2026-09-29T12:00:00.000Z"
  },
  {
    "id": "int-109",
    "candidateId": "cand-008",
    "candidateName": "Shailendra",
    "candidateEmail": "shailendra@example.com",
    "candidatePhone": "+91 98290 12484",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-29",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-8",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "EA",
      "Round 1"
    ],
    "createdAt": "2026-09-29T09:30:00.000Z",
    "updatedAt": "2026-09-29T12:00:00.000Z"
  },
  {
    "id": "int-110",
    "candidateId": "cand-009",
    "candidateName": "Dk Chawla",
    "candidateEmail": "dk.chawla@example.com",
    "candidatePhone": "+91 98290 12507",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-29",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-9",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "EA",
      "Round 1"
    ],
    "createdAt": "2026-09-29T09:30:00.000Z",
    "updatedAt": "2026-09-29T12:00:00.000Z"
  },
  {
    "id": "int-111",
    "candidateId": "cand-010",
    "candidateName": "Surya Mandotiya",
    "candidateEmail": "surya.mandotiya@example.com",
    "candidatePhone": "+91 98290 12530",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-29",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-10",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "EA",
      "Round 1"
    ],
    "createdAt": "2026-09-29T09:30:00.000Z",
    "updatedAt": "2026-09-29T12:00:00.000Z"
  },
  {
    "id": "int-112",
    "candidateId": "cand-011",
    "candidateName": "Dinesh",
    "candidateEmail": "dinesh@example.com",
    "candidatePhone": "+91 98290 12553",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Executive Office",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-29",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-11",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "EA",
      "Round 1"
    ],
    "createdAt": "2026-09-29T09:30:00.000Z",
    "updatedAt": "2026-09-29T12:00:00.000Z"
  },
  {
    "id": "int-113",
    "candidateId": "cand-012",
    "candidateName": "Shilendra Saxena",
    "candidateEmail": "shilendra.saxena@example.com",
    "candidatePhone": "+91 98290 12576",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-09-26",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-12",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-09-26T09:30:00.000Z",
    "updatedAt": "2026-09-26T12:00:00.000Z"
  },
  {
    "id": "int-114",
    "candidateId": "cand-012",
    "candidateName": "Shilendra Saxena",
    "candidateEmail": "shilendra.saxena@example.com",
    "candidatePhone": "+91 98290 12576",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-03",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-09-26T14:00:00.000Z",
    "updatedAt": "2026-10-03T15:00:00.000Z"
  },
  {
    "id": "int-115",
    "candidateId": "cand-013",
    "candidateName": "Vishvendra Singh",
    "candidateEmail": "vishvendra.singh@example.com",
    "candidatePhone": "+91 98290 12599",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-01",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-13",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-01T12:00:00.000Z"
  },
  {
    "id": "int-116",
    "candidateId": "cand-013",
    "candidateName": "Vishvendra Singh",
    "candidateEmail": "vishvendra.singh@example.com",
    "candidatePhone": "+91 98290 12599",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-03",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-10-01T14:00:00.000Z",
    "updatedAt": "2026-10-03T15:00:00.000Z"
  },
  {
    "id": "int-117",
    "candidateId": "cand-014",
    "candidateName": "Irshad Khokar",
    "candidateEmail": "irshad.khokar@example.com",
    "candidatePhone": "+91 98290 12622",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-01",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-14",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-01T12:00:00.000Z"
  },
  {
    "id": "int-118",
    "candidateId": "cand-014",
    "candidateName": "Irshad Khokar",
    "candidateEmail": "irshad.khokar@example.com",
    "candidatePhone": "+91 98290 12622",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-02",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R2 Result: Rejected",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-10-01T14:00:00.000Z",
    "updatedAt": "2026-10-02T15:00:00.000Z"
  },
  {
    "id": "int-119",
    "candidateId": "cand-015",
    "candidateName": "Achin Sharma",
    "candidateEmail": "achin.sharma@example.com",
    "candidatePhone": "+91 98290 12645",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-01",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-15",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-01T12:00:00.000Z"
  },
  {
    "id": "int-120",
    "candidateId": "cand-015",
    "candidateName": "Achin Sharma",
    "candidateEmail": "achin.sharma@example.com",
    "candidatePhone": "+91 98290 12645",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-04",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-10-01T14:00:00.000Z",
    "updatedAt": "2026-10-04T15:00:00.000Z"
  },
  {
    "id": "int-121",
    "candidateId": "cand-016",
    "candidateName": "Arya Mishra",
    "candidateEmail": "arya.mishra@example.com",
    "candidatePhone": "+91 98290 12668",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-01",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-16",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Talent",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-01T12:00:00.000Z"
  },
  {
    "id": "int-122",
    "candidateId": "cand-016",
    "candidateName": "Arya Mishra",
    "candidateEmail": "arya.mishra@example.com",
    "candidatePhone": "+91 98290 12668",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-01",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R2 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Talent",
      "Round 2"
    ],
    "createdAt": "2026-10-01T14:00:00.000Z",
    "updatedAt": "2026-10-01T15:00:00.000Z"
  },
  {
    "id": "int-123",
    "candidateId": "cand-017",
    "candidateName": "Aastha Sharma",
    "candidateEmail": "aastha.sharma@example.com",
    "candidatePhone": "+91 98290 12691",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-01",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-17",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Talent",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-01T12:00:00.000Z"
  },
  {
    "id": "int-124",
    "candidateId": "cand-017",
    "candidateName": "Aastha Sharma",
    "candidateEmail": "aastha.sharma@example.com",
    "candidatePhone": "+91 98290 12691",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-01",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R2 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Talent",
      "Round 2"
    ],
    "createdAt": "2026-10-01T14:00:00.000Z",
    "updatedAt": "2026-10-01T15:00:00.000Z"
  },
  {
    "id": "int-125",
    "candidateId": "cand-018",
    "candidateName": "Satyaveer Singh Shekhawat",
    "candidateEmail": "satyaveer.singh.shekhawat@example.com",
    "candidatePhone": "+91 98290 12714",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-01",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-18",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Talent",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-01T12:00:00.000Z"
  },
  {
    "id": "int-126",
    "candidateId": "cand-018",
    "candidateName": "Satyaveer Singh Shekhawat",
    "candidateEmail": "satyaveer.singh.shekhawat@example.com",
    "candidatePhone": "+91 98290 12714",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "department": "Human Resources",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-01",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R2 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Talent",
      "Round 2"
    ],
    "createdAt": "2026-10-01T14:00:00.000Z",
    "updatedAt": "2026-10-01T15:00:00.000Z"
  },
  {
    "id": "int-127",
    "candidateId": "cand-019",
    "candidateName": "Yudhishtir Yadav",
    "candidateEmail": "yudhishtir.yadav@example.com",
    "candidatePhone": "+91 98290 12737",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-19",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-128",
    "candidateId": "cand-019",
    "candidateName": "Yudhishtir Yadav",
    "candidateEmail": "yudhishtir.yadav@example.com",
    "candidatePhone": "+91 98290 12737",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-03",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-03T15:00:00.000Z"
  },
  {
    "id": "int-129",
    "candidateId": "cand-020",
    "candidateName": "Rohit Varma",
    "candidateEmail": "rohit.varma@example.com",
    "candidatePhone": "+91 98290 12760",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-20",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Rejected",
    "atsMatchScore": 62,
    "tags": [
      "Sales& Marketing",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-130",
    "candidateId": "cand-021",
    "candidateName": "Ashish Jangir",
    "candidateEmail": "ashish.jangir@example.com",
    "candidatePhone": "+91 98290 12783",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-21",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R1 Result: Pending",
    "atsMatchScore": 86,
    "tags": [
      "Sales& Marketing",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-131",
    "candidateId": "cand-022",
    "candidateName": "Shivam Upadhyay",
    "candidateEmail": "shivam.upadhyay@example.com",
    "candidatePhone": "+91 98290 12806",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-22",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Sales& Marketing",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-132",
    "candidateId": "cand-022",
    "candidateName": "Shivam Upadhyay",
    "candidateEmail": "shivam.upadhyay@example.com",
    "candidatePhone": "+91 98290 12806",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-03",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "Sales& Marketing",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-03T15:00:00.000Z"
  },
  {
    "id": "int-133",
    "candidateId": "cand-023",
    "candidateName": "Rohit Sood",
    "candidateEmail": "rohit.sood@example.com",
    "candidatePhone": "+91 98290 12829",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-23",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Sales& Marketing",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-134",
    "candidateId": "cand-023",
    "candidateName": "Rohit Sood",
    "candidateEmail": "rohit.sood@example.com",
    "candidatePhone": "+91 98290 12829",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-03",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "Sales& Marketing",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-03T15:00:00.000Z"
  },
  {
    "id": "int-135",
    "candidateId": "cand-024",
    "candidateName": "Virendra Kumar Jain",
    "candidateEmail": "virendra.kumar.jain@example.com",
    "candidatePhone": "+91 98290 12852",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Project Manager",
    "jobId": "job-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-24",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Project Manager",
      "Round 1"
    ],
    "createdAt": "2026-10-01T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-136",
    "candidateId": "cand-024",
    "candidateName": "Virendra Kumar Jain",
    "candidateEmail": "virendra.kumar.jain@example.com",
    "candidatePhone": "+91 98290 12852",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Project Manager",
    "jobId": "job-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-04",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "Project Manager",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-04T15:00:00.000Z"
  },
  {
    "id": "int-137",
    "candidateId": "cand-025",
    "candidateName": "Deepak Sambhwani",
    "candidateEmail": "deepak.sambhwani@example.com",
    "candidatePhone": "+91 98290 12875",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Purchase Manager – Construction Procurement",
    "jobId": "job-purchase-manager-construction",
    "department": "Procurement & Purchase",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "satyaveer.singh@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-25",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R1 Result: Pending",
    "atsMatchScore": 86,
    "tags": [
      "Purchase Manager – Construction Procurement",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-138",
    "candidateId": "cand-026",
    "candidateName": "Rakesh Kuma Jangid",
    "candidateEmail": "rakesh.kuma.jangid@example.com",
    "candidatePhone": "+91 98290 12898",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Project Manager",
    "jobId": "job-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-26",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Rejected",
    "atsMatchScore": 62,
    "tags": [
      "Project Manager",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-139",
    "candidateId": "cand-027",
    "candidateName": "Vikas Saini",
    "candidateEmail": "vikas.saini@example.com",
    "candidatePhone": "+91 98290 12921",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-27",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-140",
    "candidateId": "cand-027",
    "candidateName": "Vikas Saini",
    "candidateEmail": "vikas.saini@example.com",
    "candidatePhone": "+91 98290 12921",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-03",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-03T15:00:00.000Z"
  },
  {
    "id": "int-141",
    "candidateId": "cand-028",
    "candidateName": "Ashish Agrawal",
    "candidateEmail": "ashish.agrawal@example.com",
    "candidatePhone": "+91 98290 12944",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-28",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Architect",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-142",
    "candidateId": "cand-028",
    "candidateName": "Ashish Agrawal",
    "candidateEmail": "ashish.agrawal@example.com",
    "candidatePhone": "+91 98290 12944",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-05",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "rescheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Pending Scheduling",
    "atsMatchScore": 94,
    "tags": [
      "Architect",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-02T16:00:00.000Z"
  },
  {
    "id": "int-143",
    "candidateId": "cand-029",
    "candidateName": "Md. Wasim",
    "candidateEmail": "md.wasim@example.com",
    "candidatePhone": "+91 98290 12967",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-29",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Architect",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-144",
    "candidateId": "cand-029",
    "candidateName": "Md. Wasim",
    "candidateEmail": "md.wasim@example.com",
    "candidatePhone": "+91 98290 12967",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-10",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "Architect",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-10T15:00:00.000Z"
  },
  {
    "id": "int-145",
    "candidateId": "cand-030",
    "candidateName": "Sushant Kumar",
    "candidateEmail": "sushant.kumar@example.com",
    "candidatePhone": "+91 98290 12990",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-30",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Architect",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-146",
    "candidateId": "cand-030",
    "candidateName": "Sushant Kumar",
    "candidateEmail": "sushant.kumar@example.com",
    "candidatePhone": "+91 98290 12990",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "department": "Architecture & Design",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-04",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "Architect",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-04T15:00:00.000Z"
  },
  {
    "id": "int-147",
    "candidateId": "cand-031",
    "candidateName": "Vijay Kalra",
    "candidateEmail": "vijay.kalra@example.com",
    "candidatePhone": "+91 98290 13013",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-31",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "Sales& Marketing",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-148",
    "candidateId": "cand-031",
    "candidateName": "Vijay Kalra",
    "candidateEmail": "vijay.kalra@example.com",
    "candidatePhone": "+91 98290 13013",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "department": "Sales & Marketing",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-05",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "rescheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Pending Scheduling",
    "atsMatchScore": 94,
    "tags": [
      "Sales& Marketing",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-02T16:00:00.000Z"
  },
  {
    "id": "int-149",
    "candidateId": "cand-032",
    "candidateName": "Mohammed Faruk",
    "candidateEmail": "mohammed.faruk@example.com",
    "candidatePhone": "+91 98290 13036",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 1: Screening / Technical",
    "date": "2026-10-02",
    "startTime": "11:00",
    "endTime": "12:00",
    "durationMinutes": 60,
    "interviewerName": "Satyaveer Singh",
    "interviewerRole": "HR Recruiter / Screening Lead",
    "interviewerEmail": "dr.sharmila.yadav@urbangaon.com",
    "platform": "google_meet",
    "meetingLink": "https://meet.google.com/ug-int-r1-32",
    "status": "completed",
    "feedbackStatus": "submitted",
    "notes": "R1 Result: Cleared",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 1"
    ],
    "createdAt": "2026-10-02T09:30:00.000Z",
    "updatedAt": "2026-10-02T12:00:00.000Z"
  },
  {
    "id": "int-150",
    "candidateId": "cand-032",
    "candidateName": "Mohammed Faruk",
    "candidateEmail": "mohammed.faruk@example.com",
    "candidatePhone": "+91 98290 13036",
    "candidateLocation": "Jaipur, Rajasthan",
    "candidateAvatar": "",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "department": "Project Management",
    "round": "Round 2: Leadership / Final Evaluation",
    "date": "2026-10-04",
    "startTime": "14:00",
    "endTime": "15:00",
    "durationMinutes": 60,
    "interviewerName": "Dr Sharmila Yadav",
    "interviewerRole": "HR & Operations Director",
    "interviewerEmail": "sharmila.yadav@urbangaon.com",
    "platform": "onsite",
    "location": "UrbanGaon Corporate Headquarters, Boardroom A",
    "status": "scheduled",
    "feedbackStatus": "pending",
    "notes": "R2 Result: Scheduled",
    "atsMatchScore": 94,
    "tags": [
      "DPM",
      "Round 2"
    ],
    "createdAt": "2026-10-02T14:00:00.000Z",
    "updatedAt": "2026-10-04T15:00:00.000Z"
  }
];

export const INITIAL_CALL_RECORDS: CallRecord[] = [
  {
    "id": "call-rec-1",
    "candidateId": "cand-001",
    "candidateName": "Naveen",
    "candidatePhone": "+91 98290 12323",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-18T09:30:00.000Z",
    "durationSeconds": 335,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-09-21",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "DPM"
    ]
  },
  {
    "id": "call-rec-2",
    "candidateId": "cand-002",
    "candidateName": "Sushmita Tailang",
    "candidatePhone": "+91 98290 12346",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-09-19T09:30:00.000Z",
    "durationSeconds": 350,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Assistant (EA).",
    "followUpDate": "2026-09-21",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "EA"
    ]
  },
  {
    "id": "call-rec-3",
    "candidateId": "cand-003",
    "candidateName": "Ram Sahu",
    "candidatePhone": "+91 98290 12369",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-17T09:30:00.000Z",
    "durationSeconds": 365,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-09-26",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "DPM"
    ]
  },
  {
    "id": "call-rec-4",
    "candidateId": "cand-004",
    "candidateName": "Gaurav Kumar Goyal",
    "candidatePhone": "+91 98290 12392",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-17T09:30:00.000Z",
    "durationSeconds": 380,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-09-26",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "DPM"
    ]
  },
  {
    "id": "call-rec-5",
    "candidateId": "cand-005",
    "candidateName": "Daleep",
    "candidatePhone": "+91 98290 12415",
    "jobTitle": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-09-16T09:30:00.000Z",
    "durationSeconds": 395,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Fleet Driver.",
    "followUpDate": "2026-09-28",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹3,00,000 - ₹4,20,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "newspaper",
      "Driver"
    ]
  },
  {
    "id": "call-rec-6",
    "candidateId": "cand-006",
    "candidateName": "Sonu Kumar",
    "candidatePhone": "+91 98290 12438",
    "jobTitle": "Supervisor (Civil)",
    "jobId": "job-supervisor-civil",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-19T09:30:00.000Z",
    "durationSeconds": 410,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Civil Supervisor.",
    "followUpDate": "2026-09-21",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹4,50,000 - ₹7,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "newspaper",
      "Supervisor (Civil)"
    ]
  },
  {
    "id": "call-rec-7",
    "candidateId": "cand-007",
    "candidateName": "Maneesh",
    "candidatePhone": "+91 98290 12461",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-29T09:30:00.000Z",
    "durationSeconds": 425,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Executive Assistant (EA).",
    "followUpDate": "2026-09-29",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "EA"
    ]
  },
  {
    "id": "call-rec-8",
    "candidateId": "cand-008",
    "candidateName": "Shailendra",
    "candidatePhone": "+91 98290 12484",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-09-29T09:30:00.000Z",
    "durationSeconds": 440,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Assistant (EA).",
    "followUpDate": "2026-09-29",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "EA"
    ]
  },
  {
    "id": "call-rec-9",
    "candidateId": "cand-009",
    "candidateName": "Dk Chawla",
    "candidatePhone": "+91 98290 12507",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-29T09:30:00.000Z",
    "durationSeconds": 455,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Executive Assistant (EA).",
    "followUpDate": "2026-09-29",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "EA"
    ]
  },
  {
    "id": "call-rec-10",
    "candidateId": "cand-010",
    "candidateName": "Surya Mandotiya",
    "candidatePhone": "+91 98290 12530",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-29T09:30:00.000Z",
    "durationSeconds": 470,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Executive Assistant (EA).",
    "followUpDate": "2026-09-29",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "EA"
    ]
  },
  {
    "id": "call-rec-11",
    "candidateId": "cand-011",
    "candidateName": "Dinesh",
    "candidatePhone": "+91 98290 12553",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-09-29T09:30:00.000Z",
    "durationSeconds": 485,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Executive Assistant (EA).",
    "followUpDate": "2026-09-29",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "EA"
    ]
  },
  {
    "id": "call-rec-12",
    "candidateId": "cand-012",
    "candidateName": "Shilendra Saxena",
    "candidatePhone": "+91 98290 12576",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-09-26T09:30:00.000Z",
    "durationSeconds": 500,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-09-26",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "DPM"
    ]
  },
  {
    "id": "call-rec-13",
    "candidateId": "cand-013",
    "candidateName": "Vishvendra Singh",
    "candidatePhone": "+91 98290 12599",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 515,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-10-01",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "apna",
      "DPM"
    ]
  },
  {
    "id": "call-rec-14",
    "candidateId": "cand-014",
    "candidateName": "Irshad Khokar",
    "candidatePhone": "+91 98290 12622",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 530,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-10-01",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "apna",
      "DPM"
    ]
  },
  {
    "id": "call-rec-15",
    "candidateId": "cand-015",
    "candidateName": "Achin Sharma",
    "candidatePhone": "+91 98290 12645",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 545,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-10-01",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "apna",
      "DPM"
    ]
  },
  {
    "id": "call-rec-16",
    "candidateId": "cand-016",
    "candidateName": "Arya Mishra",
    "candidatePhone": "+91 98290 12668",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 560,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Talent Acquisition Specialist.",
    "followUpDate": "2026-10-01",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹5,50,000 - ₹8,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "Talent"
    ]
  },
  {
    "id": "call-rec-17",
    "candidateId": "cand-017",
    "candidateName": "Aastha Sharma",
    "candidatePhone": "+91 98290 12691",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 575,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Talent Acquisition Specialist.",
    "followUpDate": "2026-10-01",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹5,50,000 - ₹8,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "Talent"
    ]
  },
  {
    "id": "call-rec-18",
    "candidateId": "cand-018",
    "candidateName": "Satyaveer Singh Shekhawat",
    "candidatePhone": "+91 98290 12714",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 590,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Talent Acquisition Specialist.",
    "followUpDate": "2026-10-01",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹5,50,000 - ₹8,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "Talent"
    ]
  },
  {
    "id": "call-rec-19",
    "candidateId": "cand-019",
    "candidateName": "Yudhishtir Yadav",
    "candidatePhone": "+91 98290 12737",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 605,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "apna",
      "DPM"
    ]
  },
  {
    "id": "call-rec-20",
    "candidateId": "cand-020",
    "candidateName": "Rohit Varma",
    "candidatePhone": "+91 98290 12760",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 620,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Sales & Marketing Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Sales& Marketing"
    ]
  },
  {
    "id": "call-rec-21",
    "candidateId": "cand-021",
    "candidateName": "Ashish Jangir",
    "candidatePhone": "+91 98290 12783",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 635,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Sales & Marketing Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Sales& Marketing"
    ]
  },
  {
    "id": "call-rec-22",
    "candidateId": "cand-022",
    "candidateName": "Shivam Upadhyay",
    "candidatePhone": "+91 98290 12806",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 650,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Sales & Marketing Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Sales& Marketing"
    ]
  },
  {
    "id": "call-rec-23",
    "candidateId": "cand-023",
    "candidateName": "Rohit Sood",
    "candidatePhone": "+91 98290 12829",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 665,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Sales & Marketing Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Sales& Marketing"
    ]
  },
  {
    "id": "call-rec-24",
    "candidateId": "cand-024",
    "candidateName": "Virendra Kumar Jain",
    "candidatePhone": "+91 98290 12852",
    "jobTitle": "Project Manager",
    "jobId": "job-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-01T09:30:00.000Z",
    "durationSeconds": 680,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Senior Project Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹18,00,000 - ₹25,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "Project Manager"
    ]
  },
  {
    "id": "call-rec-25",
    "candidateId": "cand-025",
    "candidateName": "Deepak Sambhwani",
    "candidatePhone": "+91 98290 12875",
    "jobTitle": "Purchase Manager – Construction Procurement",
    "jobId": "job-purchase-manager-construction",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 695,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Satyaveer Singh. Confirmed candidature for Purchase Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹10,00,000 - ₹15,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "Purchase Manager – Construction Procurement"
    ]
  },
  {
    "id": "call-rec-26",
    "candidateId": "cand-026",
    "candidateName": "Rakesh Kuma Jangid",
    "candidatePhone": "+91 98290 12898",
    "jobTitle": "Project Manager",
    "jobId": "job-project-manager",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 710,
    "disposition": "connected_screening_failed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Project Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹18,00,000 - ₹25,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Project Manager"
    ]
  },
  {
    "id": "call-rec-27",
    "candidateId": "cand-027",
    "candidateName": "Vikas Saini",
    "candidatePhone": "+91 98290 12921",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 725,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "apna",
      "DPM"
    ]
  },
  {
    "id": "call-rec-28",
    "candidateId": "cand-028",
    "candidateName": "Ashish Agrawal",
    "candidatePhone": "+91 98290 12944",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 740,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Design Architect.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Architect"
    ]
  },
  {
    "id": "call-rec-29",
    "candidateId": "cand-029",
    "candidateName": "Md. Wasim",
    "candidatePhone": "+91 98290 12967",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 755,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Design Architect.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Architect"
    ]
  },
  {
    "id": "call-rec-30",
    "candidateId": "cand-030",
    "candidateName": "Sushant Kumar",
    "candidatePhone": "+91 98290 12990",
    "jobTitle": "Head of Architecture",
    "jobId": "job-head-architecture",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 770,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Senior Design Architect.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Architect"
    ]
  },
  {
    "id": "call-rec-31",
    "candidateId": "cand-031",
    "candidateName": "Vijay Kalra",
    "candidatePhone": "+91 98290 13013",
    "jobTitle": "Assistant Manager – Sales",
    "jobId": "job-am-sales",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 785,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Sales & Marketing Manager.",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹8,00,000 - ₹14,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Sales& Marketing"
    ]
  },
  {
    "id": "call-rec-32",
    "candidateId": "cand-032",
    "candidateName": "Mohammed Faruk",
    "candidatePhone": "+91 98290 13036",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T09:30:00.000Z",
    "durationSeconds": 800,
    "disposition": "connected_screening_passed",
    "notes": "Initial telephonic screening conducted by Dr Sharmila Yadav. Confirmed candidature for Deputy Project Manager (DPM).",
    "followUpDate": "2026-10-02",
    "followUpTime": "11:00",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "apna",
      "DPM"
    ]
  },
  {
    "id": "call-daily-101",
    "candidateId": "cand-001",
    "candidateName": "Naveen",
    "candidatePhone": "+91 98290 12323",
    "jobTitle": "Deputy Project Manager",
    "jobId": "job-deputy-project-manager",
    "recruiterName": "Satyaveer Singh",
    "callTime": "2026-10-02T10:15:00.000Z",
    "durationSeconds": 240,
    "disposition": "connected_interested",
    "notes": "Telephonic qualification call logged by Satyaveer Singh. Candidate confirmed availability.",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹12,00,000 - ₹18,00,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "referral",
      "Daily Log Call"
    ]
  },
  {
    "id": "call-daily-102",
    "candidateId": "cand-002",
    "candidateName": "Sushmita Tailang",
    "candidatePhone": "+91 98290 12346",
    "jobTitle": "EA to Director",
    "jobId": "job-ea-director",
    "recruiterName": "Dr Sharmila Yadav",
    "callTime": "2026-10-02T11:15:00.000Z",
    "durationSeconds": 260,
    "disposition": "connected_interested",
    "notes": "Telephonic qualification call logged by Dr Sharmila Yadav. Candidate confirmed availability.",
    "confirmedCurrentCtc": "₹8,50,000 P.A.",
    "confirmedExpectedCtc": "₹6,00,000 - ₹9,50,000 P.A.",
    "confirmedNoticePeriod": "30 Days",
    "isNegotiable": "yes",
    "confirmedLocation": "Jaipur, Rajasthan",
    "tags": [
      "naukri",
      "Daily Log Call"
    ]
  }
];

export const REFERRING_EMPLOYEES: { employeeName: string; employeeId: string; designation: string; department: string; email: string }[] = [];
