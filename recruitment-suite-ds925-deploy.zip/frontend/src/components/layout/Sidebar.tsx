import React from 'react';
import { 
  LayoutGrid, 
  Users, 
  PhoneCall,
  Briefcase, 
  Kanban, 
  CalendarDays, 
  LogOut,
  X 
} from 'lucide-react';
import { useRecruitment } from '../../context/RecruitmentContext';
import { useAuth } from '../../context/AuthContext';
import { UrbanGaonLogo } from '../common/UrbanGaonLogo';
import { PortalLogo } from '../common/PortalLogo';
import { CandidateSource, ROLE_LABELS } from '../../types';
import { REFERRING_EMPLOYEES } from '../../data/mockData';

export const Sidebar: React.FC = () => {
  const { user, logout } = useAuth();
  const { 
    activeView, 
    setActiveView, 
    candidates, 
    jobs, 
    interviews, 
    filters, 
    setFilters, 
    callingMetrics,
    isMobileMenuOpen,
    setIsMobileMenuOpen
  } = useRecruitment();

  const getPortalCount = (source: CandidateSource) => {
    return candidates.filter((c) => c.source === source).length;
  };

  const activeInterviewsCount = interviews.filter(
    (i) => i.status === 'scheduled' || i.status === 'confirmed' || i.status === 'in_progress' || i.status === 'rescheduled'
  ).length;

  const queuedCallsCount = candidates.filter((c) => c.isCallingQueued || c.callingDetails?.callStatus === 'in_progress').length;
  const callingCount = queuedCallsCount > 0 ? queuedCallsCount : (callingMetrics?.pendingCallsCount || 4);

  const handlePortalClick = (source: CandidateSource) => {
    setFilters({
      searchQuery: '',
      source: source,
      referrerId: undefined,
      status: 'all',
      jobId: 'all',
      experienceRange: 'all',
      recruiter: 'all',
      dateRange: 'all',
      minRating: 0
    });
    setActiveView(source);
    setIsMobileMenuOpen(false);
  };

  const handleReferralPortalClick = () => {
    setFilters({
      searchQuery: '',
      source: 'referral',
      referrerId: undefined,
      status: 'all',
      jobId: 'all',
      experienceRange: 'all',
      recruiter: 'all',
      dateRange: 'all',
      minRating: 0
    });
    setActiveView('referral');
    setIsMobileMenuOpen(false);
  };

  const handleEmployeeReferralClick = (employeeId: string) => {
    setFilters({
      searchQuery: '',
      source: 'referral',
      referrerId: employeeId,
      status: 'all',
      jobId: 'all',
      experienceRange: 'all',
      recruiter: 'all',
      dateRange: 'all',
      minRating: 0
    });
    setActiveView('referral');
    setIsMobileMenuOpen(false);
  };

  const handleGeneralViewClick = (view: string) => {
    if (view === 'candidates') {
      setFilters((prev) => ({ ...prev, source: 'all', referrerId: undefined }));
    }
    setActiveView(view);
    setIsMobileMenuOpen(false);
  };

  const renderSidebarContent = (isMobile = false) => (
    <>
      {/* Top Brand & Navigation */}
      <div className="p-3.5 space-y-5 overflow-y-auto">
        
        {/* Brand Header with Close Button for Mobile Drawer */}
        <div className="px-1.5 pt-1 pb-2 flex items-center justify-between">
          <UrbanGaonLogo size="md" className="h-9 w-auto object-contain" />
          {isMobile && (
            <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-900 transition cursor-pointer"
              title="Close navigation menu"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* Main Navigation Menu */}
        <div className="space-y-1">
          {/* Dashboard */}
          <button
            onClick={() => handleGeneralViewClick('dashboard')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] transition-all tracking-tight ${
              activeView === 'dashboard' || activeView === 'overview'
                ? 'bg-[#2563eb] text-white font-medium shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <LayoutGrid size={16} className={activeView === 'dashboard' || activeView === 'overview' ? 'text-white' : 'text-slate-400'} />
            <span>Dashboard</span>
          </button>

          {/* All Candidates */}
          <button
            onClick={() => handleGeneralViewClick('candidates')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[13px] transition-all tracking-tight ${
              activeView === 'candidates'
                ? 'bg-[#2563eb] text-white font-medium shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Users size={16} className={activeView === 'candidates' ? 'text-white' : 'text-slate-400'} />
              <span>All Candidates</span>
            </div>
            <span className={`text-[10px] font-normal px-1.5 py-0.2 rounded-full ${
              activeView === 'candidates' ? 'bg-blue-800/80 text-white' : 'bg-slate-100 text-slate-500'
            }`}>
              {candidates.length}
            </span>
          </button>

          {/* Calling Desk */}
          <button
            onClick={() => handleGeneralViewClick('calling')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[13px] transition-all tracking-tight ${
              activeView === 'calling' || activeView === 'calling-desk'
                ? 'bg-[#2563eb] text-white font-medium shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PhoneCall size={16} className={activeView === 'calling' || activeView === 'calling-desk' ? 'text-white' : 'text-emerald-600'} />
              <span>Calling</span>
            </div>
            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
              activeView === 'calling' || activeView === 'calling-desk' ? 'bg-blue-800/80 text-white' : 'bg-emerald-50 text-emerald-700'
            }`}>
              {callingCount}
            </span>
          </button>

          {/* Interview Scheduler */}
          <button
            onClick={() => handleGeneralViewClick('scheduler')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[13px] transition-all tracking-tight ${
              activeView === 'scheduler' || activeView === 'interview-scheduler'
                ? 'bg-[#2563eb] text-white font-medium shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <CalendarDays size={16} className={activeView === 'scheduler' || activeView === 'interview-scheduler' ? 'text-white' : 'text-blue-600'} />
              <span className="font-medium">Interview Scheduler</span>
            </div>
            <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${
              activeView === 'scheduler' || activeView === 'interview-scheduler' ? 'bg-blue-800/80 text-white' : 'bg-blue-50 text-blue-700'
            }`}>
              {activeInterviewsCount}
            </span>
          </button>

          {/* Job Openings */}
          <button
            onClick={() => handleGeneralViewClick('jobs')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[13px] transition-all tracking-tight ${
              activeView === 'jobs'
                ? 'bg-[#2563eb] text-white font-medium shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Briefcase size={16} className={activeView === 'jobs' ? 'text-white' : 'text-slate-400'} />
              <span>Job Openings</span>
            </div>
            <span className={`text-[10px] font-normal px-1.5 py-0.2 rounded-full ${
              activeView === 'jobs' ? 'bg-blue-800/80 text-white' : 'bg-slate-100 text-slate-500'
            }`}>
              {jobs.length}
            </span>
          </button>

          {/* Pipeline Stages */}
          <button
            onClick={() => handleGeneralViewClick('pipeline')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] transition-all tracking-tight ${
              activeView === 'pipeline'
                ? 'bg-[#2563eb] text-white font-medium shadow-xs'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <Kanban size={16} className={activeView === 'pipeline' ? 'text-white' : 'text-slate-400'} />
            <span>Pipeline Stages</span>
          </button>
        </div>

        {/* Portals Section */}
        <div className="pt-2 border-t border-slate-100 space-y-0.5">
          <div className="px-3 pb-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Sourcing Portals
          </div>

          <button
            onClick={() => handlePortalClick('linkedin')}
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[13px] transition-all tracking-tight ${
              activeView === 'linkedin'
                ? 'bg-sky-50 text-sky-700 font-medium'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PortalLogo source="linkedin" size={17} />
              <span>LinkedIn</span>
            </div>
            <span className="text-[11px] text-slate-400 font-normal">
              {getPortalCount('linkedin')}
            </span>
          </button>

          <button
            onClick={() => handlePortalClick('naukri')}
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[13px] transition-all tracking-tight ${
              activeView === 'naukri'
                ? 'bg-blue-50 text-blue-700 font-medium'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PortalLogo source="naukri" size={17} />
              <span>Naukri.com</span>
            </div>
            <span className="text-[11px] text-slate-400 font-normal">
              {getPortalCount('naukri')}
            </span>
          </button>

          <button
            onClick={() => handlePortalClick('indeed')}
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[13px] transition-all tracking-tight ${
              activeView === 'indeed'
                ? 'bg-indigo-50 text-indigo-700 font-medium'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PortalLogo source="indeed" size={17} />
              <span>Indeed</span>
            </div>
            <span className="text-[11px] text-slate-400 font-normal">
              {getPortalCount('indeed')}
            </span>
          </button>

          <button
            onClick={() => handlePortalClick('apna')}
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[13px] transition-all tracking-tight ${
              activeView === 'apna'
                ? 'bg-emerald-50 text-emerald-700 font-medium'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PortalLogo source="apna" size={17} />
              <span>Apna.co</span>
            </div>
            <span className="text-[11px] text-slate-400 font-normal">
              {getPortalCount('apna')}
            </span>
          </button>

          <button
            onClick={() => handlePortalClick('urbangaon')}
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[13px] transition-all tracking-tight ${
              activeView === 'urbangaon'
                ? 'bg-blue-50 text-blue-700 font-medium'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PortalLogo source="urbangaon" size={17} />
              <span>UrbanGaon</span>
            </div>
            <span className="text-[11px] text-slate-400 font-normal">
              {getPortalCount('urbangaon')}
            </span>
          </button>
        </div>

        {/* Employee Referral Section directly below Sourcing Portals */}
        <div className="pt-2.5 border-t border-slate-100 space-y-0.5">
          <div className="px-3 pb-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Employee Referral
          </div>

          {/* All Referrals item */}
          <button
            onClick={() => handleReferralPortalClick()}
            className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[13px] transition-all tracking-tight ${
              activeView === 'referral'
                ? 'bg-purple-50 text-purple-700 font-medium'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50 font-normal'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <PortalLogo source="referral" size={17} />
              <span>All Referrals</span>
            </div>
            <span className={`text-[11px] font-normal ${
              activeView === 'referral' ? 'text-purple-600 font-semibold' : 'text-slate-400'
            }`}>
              {getPortalCount('referral')}
            </span>
          </button>
        </div>

      </div>

      {/* Bottom User Profile Footer */}
      <div className="p-3 border-t border-slate-100">
        <div className="flex items-center justify-between text-xs px-1">
          <div className="flex items-center gap-2 min-w-0 flex-1 mr-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 ${
              user?.role === 'admin' ? 'bg-emerald-100 text-emerald-700' :
              user?.role === 'recruiter' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'
            }`}>
              {user?.avatar || user?.name?.slice(0, 2).toUpperCase() || 'UG'}
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-semibold text-slate-800 text-[11px] tracking-tight truncate">
                {user?.name === 'Akash Das' ? 'Urban Gaon' : (user?.name || 'Urban Gaon')}
              </div>
              <div className="text-[10px] text-slate-400 truncate">
                {user ? ROLE_LABELS[user.role]?.badge : 'Active'}
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              logout();
              setIsMobileMenuOpen(false);
            }}
            className="flex items-center gap-1 text-[11px] font-medium text-rose-500 hover:text-rose-600 transition tracking-tight shrink-0 cursor-pointer"
            title="Sign out of recruitment portal"
          >
            <LogOut size={12} />
            <span>Sign out</span>
          </button>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* 1. Desktop Sticky Sidebar (Visible on lg+ screens: laptops, desktops, ultra-wide) */}
      <aside className="hidden lg:flex w-56 bg-white border-r border-slate-100 flex-col justify-between h-screen sticky top-0 shrink-0 select-none z-30 font-sans tracking-tight">
        {renderSidebarContent(false)}
      </aside>

      {/* 2. Mobile / Tablet Drawer (Visible on screens < lg) */}
      {/* Drawer Overlay Backdrop */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-40 lg:hidden transition-opacity animate-fade-in"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Drawer Panel */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 max-w-[85vw] bg-white flex flex-col justify-between shadow-2xl lg:hidden transform transition-transform duration-300 ease-in-out select-none font-sans tracking-tight ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {renderSidebarContent(true)}
      </aside>
    </>
  );
};
